<?php include 'header.php'; ?>

<?php 
     $id = basename ( $_SERVER['REQUEST_URI'] );

                    $kategoriler = $db->prepare("SELECT * FROM kategoriler WHERE kat_id=?");
                    $kategoriler->execute(array($id));
                    $kategori = $kategoriler->fetch(PDO::FETCH_ASSOC);
?>
    

     <div id="content" class="mt-2">
          <div class="container">

     <div class="row" >
                         <div class="card card-info widget" id="search-widget" style=" width: 100%;">
                              <div class="card-header">
                                   <i class="material-icons">format_align_left</i>
                                   <?php echo $kategori["kat_isim"]; ?>
                              </div>
               <div class="col-md-12" style="background: #f9f9f1; padding-top: 20px;">

               <?php 

               $id = basename ( $_SERVER['REQUEST_URI'] );

               $yazilarim = $db->prepare("SELECT * FROM yazilarim
                    INNER JOIN kategoriler ON kategoriler.kat_id = yazilarim.yazi_kategori WHERE yazi_kategori=?
                ORDER BY yazi_id DESC");
               $yazilarim->execute(array($id));
               $yazicek = $yazilarim->fetchALL(PDO::FETCH_ASSOC);
               $yazisor = $yazilarim->rowCount();

               if ($yazisor) {
                   
                    foreach ($yazicek as $yazicekk) {



                    $yorumlar = $db->prepare("SELECT * FROM yorumlar WHERE yorum_konu_id=? AND yorum_durum=?");
                    $yorumlar->execute(array($yazicekk["yazi_id"],1));
                    $yorumsay = $yorumlar->rowCount();

                    if($yorumsay){
                        ?>

                     <div class="col-lg-4">
                         <div class="card article">
                              <div class="card-cover">
                                   <div class="details" style="text-align: center;">
                                        <small><i class="material-icons">chat_bubble_outline</i> <?php echo $yorumsay; ?> Yorum</small>
                                   </div>
                                   <img width="100%" height="100%" src="<?php echo $ayarrow["site_url"]; ?>images/yazilarim/<?php echo $yazicekk["yazi_resim"]; ?>">
                              </div>
                              <div class="card-block">
                                   <a href="<?php echo $ayarrow["site_url"]; ?>icerik/<?php echo seo($yazicekk["yazi_baslik"]).'/'.$yazicekk["yazi_id"]; ?>"><h6><?php echo substr($yazicekk["yazi_baslik"], 0,35); ?>...</h6></a>
                                   <small style="float: left;"><b><em> <span class="fa fa-tags"></span> <?php echo $yazicekk["kat_isim"]; ?></em></b></small> <small style="float: right;"><em><b><span class="fa fa-clock-o"></span> <?php echo timeAgo($yazicekk["yazi_tarih"]); ?></em></b></small>
                              </div>
                              
                         </div>
                    </div>

                        <?php
                   }else{
                    ?>

                    <div class="col-lg-4">
                         <div class="card article">
                              <div class="card-cover">
                                   <div class="details" style="text-align: center;">
                                        <small><i class="material-icons">chat_bubble_outline</i> <?php echo '0' ?> Yorum</small>
                                   </div>
                                   <img width="100%" height="100%" src="<?php echo $ayarrow["site_url"]; ?>images/yazilarim/<?php echo $yazicekk["yazi_resim"]; ?>">
                              </div>
                              <div class="card-block">
                                   <a href="<?php echo $ayarrow["site_url"]; ?>icerik/<?php echo seo($yazicekk["yazi_baslik"]).'/'.$yazicekk["yazi_id"]; ?>"><h6><?php echo substr($yazicekk["yazi_baslik"], 0,35); ?>...</h6></a>
                                   <small style="float: left;"><b><em> <span class="fa fa-tags"></span> <?php echo $yazicekk["kat_isim"]; ?></em></b></small> <small style="float: right;"><em><b><span class="fa fa-clock-o"></span> <?php echo timeAgo($yazicekk["yazi_tarih"]); ?></em></b></small>
                              </div>
                              
                         </div>
                    </div>

                    <?php
                    }

                 }

               }else{

                    echo "<div style='background: #fff; margin-top: -20px'>Bu kategori de bir yazı bulunmamaktadır!</div>"; 
               }


               ?>
                   
                   

               </div>
          </div>
     </div>



     <!-- Remove Work -->
     <div class="modal fade" id="remove_article" tabindex="-1">
          <div class="modal-dialog">
               <div class="modal-content">
                    <div class="modal-header">
                         <h4 class="modal-title">Uyarı</h4>
                    </div>
                    <div class="modal-body">
                         Bu yazıyı silmek istediğinize emin misiniz?
                    </div>
                    <div class="modal-footer">
                         <button type="button" class="btn btn-danger fab"><i class="material-icons">delete</i></button>
                         <button type="button" class="btn btn-secondary fab" class="close" data-dismiss="modal"><i class="material-icons">close</i></button>
                    </div>
               </div>

          </div>
     </div>
        </div>
        <h6 style="text-align: center;"> <?php include 'footer.php'; ?></h6> 
