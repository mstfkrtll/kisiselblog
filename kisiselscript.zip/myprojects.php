<?php include 'header.php'; ?>

   
     <div id="content" class="mt-2">
          <div class="container">  
               <div class="row">
                    <div class="card card-info widget" id="search-widget" style="background: #B71C1C; width: 100%;" >
                              <div class="card-header">
                                   <i class="material-icons">code</i>
                                   Kodladığım Scriptler
                              </div>
               <div class="col-md-12" style="background: #f9f9f1; padding-top: 20px;">

<?php 

               $projelerim = $db->prepare("SELECT * FROM projelerim");
               $projelerim->execute();
               $projecek = $projelerim->fetchALL(PDO::FETCH_ASSOC);
               $projesor = $projelerim->rowCount();

               if ($projesor) {
                   
                    foreach ($projecek as $projecekk) {
                        ?>

                     <div class="col-lg-4">
                         <div class="card article">
                              <div class="card-cover">
                                   <img width="100%" height="100%" src="images/projelerim/<?php echo $projecekk["proje_resim"]; ?>">
                              </div>
                              <div class="card-block" style="text-align: center;">
                                   <a href="<?php echo $projecekk["proje_link"]; ?>" style="color: #B71C1C;"><h6><?php echo $projecekk["proje_isim"]; ?></h6></a>
                                   <small><em><?php echo timeAgo($projecekk["proje_tarih"]); ?></em></small>
                              </div>
                              
                         </div>
                    </div>

                        <?php
                    }


               }else{
                    echo "<span>Proje bulunmamaktadır!</span>";
               }


               ?>

               </div>
          </div>
          </div>
     </div>


 <h6 style="text-align: center;"> <?php include 'footer.php'; ?></h6> 