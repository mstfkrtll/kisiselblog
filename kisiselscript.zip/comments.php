<!DOCTYPE html>
<html lang="en">
<head>

     <meta charset="UTF-8">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <meta http-equiv="X-UA-Compatible" content="ie=edge">
     <title>Mstfkrtll.com / Kişisel Web Scripti</title>

     <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:100,300,400,500,700,900">
     <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
     <link rel="stylesheet" href="assets/plugins/bootstrap/css/bootstrap.min.css">
     <link rel="stylesheet" href="assets/plugins/bootstrap/css/bootstrap-flex.min.css">
     <link rel="stylesheet" href="assets/plugins/tether/css/tether.min.css">
     <link rel="stylesheet" href="assets/plugins/jQueryFiler/css/jquery.filer.css">
     <link rel="stylesheet" href="assets/plugins/toastr8/toastr8.min.css">
     <link rel="stylesheet" href="assets/css/style.css">
     <link rel="stylesheet" href="assets/css/custom.css">

     <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
     <script type="text/javascript" src="assets/plugins/tether/js/tether.min.js"></script>
     <script type="text/javascript" src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>
     <script type="text/javascript" src="assets/plugins/jQueryFiler/js/jquery.filer.min.js"></script>
     <script type="text/javascript" src="assets/plugins/toastr8/toastr8.min.js"></script>
     <script type="text/javascript" src="assets/js/app.js"></script>

</head>
<body>

     <nav class="navbar navbar-light" id="menu">
          <div class="container">
               <a href="index.html" class="navbar-brand" ><img style="border: 10px double #445;" src="images/ben.jpg" alt=""></a>

               <div class="row">
                    <div class="col-lg-2">
                         <a href="index.html" style="text-decoration: none;"><div class="card card-teal mini-widget" style="margin: 0;">
                              <i class="material-icons">home</i>
                              <div class="card-block">
                                   <p class="lead">Anasayfa</p>
                                   <p class="count">Home</p>
                              </div>
                         </div></a>
                    </div>

                    <div class="col-lg-2">
                         <a href="hakkimda.html" style="text-decoration: none;"><div class="card card-red mini-widget" style="margin: 0">
                              <i class="material-icons">assignment_ind</i>
                              <div class="card-block">
                                   <p class="lead">Hakkımda</p>
                                   <p class="count">Mustafa Kartal</p>
                              </div>
                         </div></a>
                    </div>

                    <div class="col-lg-2">
                         <a href="yazilarim.html" style="text-decoration: none;"><div class="card card-blue mini-widget" style="margin: 0">
                              <i class="material-icons">format_align_left</i>
                              <div class="card-block">
                                   <p class="lead">Yazılarım</p>
                                   <p class="count">61</p>
                              </div>
                         </div></a>
                    </div>
                    <div class="col-lg-2">
                         <a href="works.html" style="text-decoration: none;"><div class="card card-indigo mini-widget" style="margin: 0">
                              <i class="material-icons">work</i>
                              <div class="card-block">
                                   <p class="lead">Referanslar</p>
                                   <p class="count">65</p>
                              </div>
                         </div></a>
                    </div>
                    <div class="col-lg-2">
                         <a href="tags.html" style="text-decoration: none;"><div class="card card-yellow mini-widget" style="margin: 0">
                              <i class="material-icons">local_offer</i>
                              <div class="card-block">
                                   <p class="lead">Kategoriler</p>
                                   <p class="count">65</p>
                              </div>
                         </div></a>
                    </div>
                    
                    <div class="col-lg-2">
                         <a href="" style="text-decoration: none;"><div class="card card-dark-red mini-widget" style="margin: 0">
                              <i class="material-icons">code</i>
                              <div class="card-block">
                                   <p class="lead">Projelerim</p>
                                   <p class="count">65</p>
                              </div>
                         </div></a>
                    </div>
                    
               </div>
              
          </div>
     </nav>

     <nav class="navbar navbar-light bg-faded" id="submenu">
          <div class="container">
               <div class="navbar-brand">
                    <p>Yorumlar</p>
                    <small>Yeni yorum bulunmuyor</small>
               </div>
          </div>
     </nav>

     <div id="content" class="mt-2">
          <div class="container">

               <div class="row">

                    <div class="col-lg-4">
                         <div class="card comment">
                              <div class="card-header">
                                   <img src="https://randomuser.me/api/portraits/women/80.jpg" alt="">
                                   <div class="header">
                                        <div class="fullname">Elif Mayhoş</div>
                                        <div class="time">10 dakika önce</div>
                                        <div class="dropdown">
                                             <button class="btn dropdown-toggle" data-toggle="dropdown"><i class="material-icons">more_vert</i></button>
                                             <div class="dropdown-menu dropdown-menu-right">
                                                  <button class="dropdown-item" data-toggle="modal" data-target="#edit_modal" data-id="1"><i class="material-icons">check</i> <span>Onayla</span></button>
                                                  <button class="dropdown-item" data-toggle="modal" data-target="#edit_modal" data-id="1"><i class="material-icons">edit</i> <span>Düzenle</span></button>
                                                  <button class="dropdown-item" data-toggle="modal" data-target="#edit_modal" data-id="1"><i class="material-icons">delete</i> <span>Sil</span></button>
                                             </div>
                                        </div>
                                   </div>
                              </div>
                              <div class="card-block">
                                   <p class="comment">Lorem Ipsum, dizgi ve baskı endüstrisinde kullanılan mıgır metinlerdir.</p>
                                   <a href="" class=""><i class="material-icons">open_in_new</i> PHP Nedir?</a>
                                   <p class="detail">
                                        <small class="text-muted">elif.mayhoş@example.com</small>
                                        <small class="text-muted float-xs-right">127.0.0.1</small>
                                   </p>
                              </div>
                         </div>
                    </div>

                    <div class="col-lg-4">
                         <div class="card comment new">
                              <div class="card-header">
                                   <img src="https://randomuser.me/api/portraits/women/21.jpg" alt="">
                                   <div class="header">
                                        <div class="fullname">Deniz Ekşioğlu</div>
                                        <div class="time">10 dakika önce</div>
                                        <div class="dropdown">
                                             <button class="btn dropdown-toggle" data-toggle="dropdown"><i class="material-icons">more_vert</i></button>
                                             <div class="dropdown-menu dropdown-menu-right">
                                                  <button class="dropdown-item" data-toggle="modal" data-target="#edit_modal" data-id="1"><i class="material-icons">check</i> <span>Onayla</span></button>
                                                  <button class="dropdown-item" data-toggle="modal" data-target="#edit_modal" data-id="1"><i class="material-icons">edit</i> <span>Düzenle</span></button>
                                                  <button class="dropdown-item" data-toggle="modal" data-target="#edit_modal" data-id="1"><i class="material-icons">delete</i> <span>Sil</span></button>
                                             </div>
                                        </div>
                                   </div>
                              </div>
                              <div class="card-block">
                                   <p class="comment">Lorem Ipsum, dizgi ve baskı endüstrisinde kullanılan mıgır metinlerdir. Lorem Ipsum, adı bilinmeyen bir matbaacının bir hurufat numune kitabı oluşturmak üzere bir yazı galerisini alarak karıştırdığı 1500'lerden beri endüstri standardı sahte metinler olarak kullanılmıştır.</p>
                                   <a href="" class=""><i class="material-icons">open_in_new</i> PHP Nedir?</a>
                                   <p class="detail">
                                        <small class="text-muted">deniz.ekşioğlu@example.com</small>
                                        <small class="text-muted float-xs-right">127.0.0.1</small>
                                   </p>
                              </div>
                         </div>
                    </div>

                    <div class="col-lg-4">
                         <div class="card comment">
                              <div class="card-header">
                                   <img src="https://randomuser.me/api/portraits/men/20.jpg" alt="">
                                   <div class="header">
                                        <div class="fullname">Efe Yetkiner</div>
                                        <div class="time">10 dakika önce</div>
                                        <div class="dropdown">
                                             <button class="btn dropdown-toggle" data-toggle="dropdown"><i class="material-icons">more_vert</i></button>
                                             <div class="dropdown-menu dropdown-menu-right">
                                                  <button class="dropdown-item" data-toggle="modal" data-target="#edit_modal" data-id="1"><i class="material-icons">check</i> <span>Onayla</span></button>
                                                  <button class="dropdown-item" data-toggle="modal" data-target="#edit_modal" data-id="1"><i class="material-icons">edit</i> <span>Düzenle</span></button>
                                                  <button class="dropdown-item" data-toggle="modal" data-target="#edit_modal" data-id="1"><i class="material-icons">delete</i> <span>Sil</span></button>
                                             </div>
                                        </div>
                                   </div>
                              </div>
                              <div class="card-block">
                                   <p class="comment">Lorem Ipsum, dizgi ve baskı endüstrisinde kullanılan mıgır metinlerdir. Lorem Ipsum, adı bilinmeyen bir matbaacının bir hurufat numune kitabı oluşturmak üzere bir yazı galerisini alarak karıştırdığı 1500'lerden beri endüstri standardı sahte metinler olarak kullanılmıştır. Beşyüz yıl boyunca varlığını sürdürmekle kalmamış, aynı zamanda pek değişmeden elektronik dizgiye de sıçramıştır.</p>
                                   <a href="" class=""><i class="material-icons">open_in_new</i> PHP Nedir?</a>
                                   <p class="detail">
                                        <small class="text-muted">efe.yetkiner@example.com</small>
                                        <small class="text-muted float-xs-right">127.0.0.1</small>
                                   </p>
                              </div>
                         </div>
                    </div>

                    <div class="col-lg-4">
                         <div class="card comment">
                              <div class="card-header">
                                   <img src="https://randomuser.me/api/portraits/women/45.jpg" alt="">
                                   <div class="header">
                                        <div class="fullname">Meral Durak</div>
                                        <div class="time">10 dakika önce</div>
                                        <div class="dropdown">
                                             <button class="btn dropdown-toggle" data-toggle="dropdown"><i class="material-icons">more_vert</i></button>
                                             <div class="dropdown-menu dropdown-menu-right">
                                                  <button class="dropdown-item" data-toggle="modal" data-target="#edit_modal" data-id="1"><i class="material-icons">check</i> <span>Onayla</span></button>
                                                  <button class="dropdown-item" data-toggle="modal" data-target="#edit_modal" data-id="1"><i class="material-icons">edit</i> <span>Düzenle</span></button>
                                                  <button class="dropdown-item" data-toggle="modal" data-target="#edit_modal" data-id="1"><i class="material-icons">delete</i> <span>Sil</span></button>
                                             </div>
                                        </div>
                                   </div>
                              </div>
                              <div class="card-block">
                                   <p class="comment">Lorem Ipsum, dizgi ve baskı endüstrisinde kullanılan mıgır metinlerdir. Lorem Ipsum, adı bilinmeyen bir matbaacının bir hurufat numune kitabı oluşturmak üzere bir yazı galerisini alarak karıştırdığı 1500'lerden beri endüstri standardı sahte metinler olarak kullanılmıştır. Beşyüz yıl boyunca varlığını sürdürmekle kalmamış, aynı zamanda pek değişmeden elektronik dizgiye de sıçramıştır.</p>
                                   <a href="" class=""><i class="material-icons">open_in_new</i> PHP Nedir?</a>
                                   <p class="detail">
                                        <small class="text-muted">meral.durak@example.com</small>
                                        <small class="text-muted float-xs-right">127.0.0.1</small>
                                   </p>
                              </div>
                         </div>
                    </div>

                    <div class="col-lg-4">
                         <div class="card comment">
                              <div class="card-header">
                                   <img src="https://randomuser.me/api/portraits/women/71.jpg" alt="">
                                   <div class="header">
                                        <div class="fullname">Kübra Egeli</div>
                                        <div class="time">10 dakika önce</div>
                                        <div class="dropdown">
                                             <button class="btn dropdown-toggle" data-toggle="dropdown"><i class="material-icons">more_vert</i></button>
                                             <div class="dropdown-menu dropdown-menu-right">
                                                  <button class="dropdown-item" data-toggle="modal" data-target="#edit_modal" data-id="1"><i class="material-icons">check</i> <span>Onayla</span></button>
                                                  <button class="dropdown-item" data-toggle="modal" data-target="#edit_modal" data-id="1"><i class="material-icons">edit</i> <span>Düzenle</span></button>
                                                  <button class="dropdown-item" data-toggle="modal" data-target="#edit_modal" data-id="1"><i class="material-icons">delete</i> <span>Sil</span></button>
                                             </div>
                                        </div>
                                   </div>
                              </div>
                              <div class="card-block">
                                   <p class="comment">Lorem Ipsum, dizgi ve baskı endüstrisinde kullanılan mıgır metinlerdir. Lorem Ipsum, adı bilinmeyen bir matbaacının bir hurufat numune kitabı oluşturmak üzere bir yazı galerisini alarak karıştırdığı 1500'lerden beri endüstri standardı sahte metinler olarak kullanılmıştır.</p>
                                   <a href="" class=""><i class="material-icons">open_in_new</i> PHP Nedir?</a>
                                   <p class="detail">
                                        <small class="text-muted">kübra.egeli@example.com</small>
                                        <small class="text-muted float-xs-right">127.0.0.1</small>
                                   </p>
                              </div>
                         </div>
                    </div>

                    <div class="col-lg-4">
                         <div class="card comment">
                              <div class="card-header">
                                   <img src="https://randomuser.me/api/portraits/men/11.jpg" alt="">
                                   <div class="header">
                                        <div class="fullname">Kuzey Durmaz</div>
                                        <div class="time">10 dakika önce</div>
                                        <div class="dropdown">
                                             <button class="btn dropdown-toggle" data-toggle="dropdown"><i class="material-icons">more_vert</i></button>
                                             <div class="dropdown-menu dropdown-menu-right">
                                                  <button class="dropdown-item" data-toggle="modal" data-target="#edit_modal" data-id="1"><i class="material-icons">check</i> <span>Onayla</span></button>
                                                  <button class="dropdown-item" data-toggle="modal" data-target="#edit_modal" data-id="1"><i class="material-icons">edit</i> <span>Düzenle</span></button>
                                                  <button class="dropdown-item" data-toggle="modal" data-target="#edit_modal" data-id="1"><i class="material-icons">delete</i> <span>Sil</span></button>
                                             </div>
                                        </div>
                                   </div>
                              </div>
                              <div class="card-block">
                                   <p class="comment">Lorem Ipsum, dizgi ve baskı endüstrisinde kullanılan mıgır metinlerdir.</p>
                                   <a href="" class=""><i class="material-icons">open_in_new</i> PHP Nedir?</a>
                                   <p class="detail">
                                        <small class="text-muted">kuzey.durmaz@example.com</small>
                                        <small class="text-muted float-xs-right">127.0.0.1</small>
                                   </p>
                              </div>
                         </div>
                    </div>

               </div>
          </div>
     </div>

</body>
</html>
