<?php include 'header.php';
	
 ?>

     <?php 

               $id = basename ( $_SERVER['REQUEST_URI'] );

               $yazilarim = $db->prepare("SELECT * FROM yazilarim 
                         INNER JOIN kategoriler ON kategoriler.kat_id = yazilarim.yazi_kategori
                    WHERE yazi_id=?");
               $yazilarim->execute(array($id));
               $yazicek = $yazilarim->fetch(PDO::FETCH_ASSOC);



   ?>

     <div id="content" class="mt-2">
          <div class="container">

     <div class="row" >
                         <div class="card card-info widget" id="search-widget" style=" width: 100%;">
                              <div class="card-header">
                                   
                                   <div class="row">
                <div class="col-md-4" ><span class="fa fa-book"></span> <?php echo $yazicek["yazi_baslik"]; ?></div>
                <!-- yorum toplam -->
                 <?php
                $yorumlar = $db->prepare("SELECT * FROM yorumlar WHERE yorum_konu_id=? AND yorum_durum=?");
                $yorumcek = $yorumlar->execute(array($id,1));
                $yorumsay = $yorumlar->rowCount();
                if ($yorumsay) {
                  ?>
                  <div class="col-md-2" ><span class="fa fa-comments"></span> <?php echo $yorumsay; ?></div>
                  <?php
                }else{
                  ?>
                   <div class="col-md-2" ><span class="fa fa-comments"></span> <?php echo '0' ?></div>
                   <?php
                }
                ?>
                
              	<div class="col-md-3" style="text-align: center;" ><span class="fa fa-tags"></span> <?php echo $yazicek["kat_isim"]; ?></div>
              	<div class="col-md-3" style="text-align: right;" ><span class="fa fa-clock-o"></span> <?php echo timeAgo($yazicek["yazi_tarih"]); ?></div>
              </div>
                              </div>
               <div class="col-md-12" style="background: #f9f9f1; padding-top: 20px;">

              
               
	               <div class="row">
	                    <div class="col-md-2"></div>
	                         <div class="col-md-8">
	                              <img style="width: 100%; height: 350px;" src="<?php echo $ayarrow["site_url"]; ?>images/yazilarim/<?php echo $yazicek["yazi_resim"]; ?>">
	                         </div>
	                    <div class="col-md-2"></div>

	               </div>

	               <div class="row">
	               <div class="col-md-12" style="text-align: center; margin-top: 10px;">
	               <h5><?php echo $yazicek["yazi_baslik"]; ?></h5>
	                   <p><?php echo $yazicek["yazi_icerik"]; ?></p>
	               </div>
	               </div>
               </div>
          </div>



          <!-- yorumlar -->

             <div class="card card-danger widget" id="logs-widget" style="width: 100%;">
                              <div class="card-header"><i class="material-icons">comment</i>Yorumlar</div>
                              <ul class="list-group list-group-flush">
                              <?php 

                              $yorumlar = $db->prepare("SELECT * FROM yorumlar WHERE yorum_konu_id=? AND yorum_durum=?");
                              $yorumlar->execute(array($id,1));
                              $yorumcek = $yorumlar->fetchALL(PDO::FETCH_ASSOC);
                              $yorumsay = $yorumlar->rowCount();

                              if ($yorumsay) {
                              	
                              	foreach ($yorumcek as $yorumcekk) {

                              		?>

                              		 <li class="list-group-item">
                                        <i class="material-icons icon">comment</i>
                                          
                                            
                                        <div class="content">
                                             <p><em><b><?php echo $yorumcekk["yorum_ekleyen"]; ?></b></em></p>
                                             <p><?php echo $yorumcekk["yorum_icerik"]; ?></p>
                                             <p>
                                                  <em><small style="float: left;"><b><?php echo timeAgo($yorumcekk["yorum_tarih"]); ?></b></small></em>
                                                  <em><small><?php echo $yorumcekk["yorum_eposta"]; ?></small></em>
                                             </p>
                                             
                                             <br>
                                             
                                        </div>
                                   </li>

                              		<?php
                              	}

                              }else{

                              	echo "<div class='col-md-12' style='background: #fff;'>Bu konuya ilk yorumu sen yap..</div>";  

                              }

                              ?>
                                  
                              </ul>
                         </div>	


           <!-- YORUM YAP -->

            <div class="card card-danger widget" id="logs-widget" style="width: 100%;">
                              <div class="card-header"><i class="material-icons">comment</i>Yorum Yap</div>
                              <ul class="list-group list-group-flush">
                               <li class="list-group-item">
                                        <div class="content" style="padding-left: 15px;">
      
<?php

  if (isset($_POST["comments"])) {
    
    $id = basename ( $_SERVER['REQUEST_URI'] );

    $isim = $_POST["isim"];
    $mail = trim($_POST["mail"]);
    $mesaj = $_POST["mesaj"];


    if (!$isim || !$mail || !$mesaj) {
      ?>
     <script>

    alert("Lütfen boş alan bırakmayınız!");
  
</script>


      <?php
      $url = $_SERVER["HTTP_REFERER"];
      header("refresh: 0.05; url=$url");

    }else{

      $yorum = $db->prepare("INSERT INTO yorumlar SET
          yorum_ekleyen=?,
          yorum_eposta=?,
          yorum_icerik=?,
          yorum_konu_id=?
        ");


      $ekle = $yorum->execute(array($isim,$mail,$mesaj,$id));

      if ($ekle) {
      ?>
           <script>

          alert("Yorumunuz başarıyla gönderilmiştir!");
        
      </script>


      <?php
        $url = $_SERVER["HTTP_REFERER"];
        header("refresh: 1; url=$url");


      }else{

        ?>
           <script>

          alert("Yorumunuz eklenirken bir hata oluştu!");
        
      </script>


      <?php

      }


    }


  }else{

?>

      <form action="" method="POST">
		  <div class="form-group">
		    <label style="color: #444;">Ad-Soyad :</label>
		    <input type="text" name="isim" class="form-control" placeholder="Mustafa Kartal">
		  </div>
		  <div class="form-group">
		    <label style="color: #444;">E-Posta</label>
		    <input type="email" name="mail" class="form-control" placeholder="mstfkrtll@yandex.com">
		  </div>
		  <div class="form-group">
		  <label style="color: #444;">Yorumunuz:</label>
		  <textarea name="mesaj" class="form-control" rows="3" placeholder="Yorumunuzz..."></textarea>
		  </div>
		   <input type="submit" name="comments" class="btn btn-success" value="Yorum Yap">
		</form>
                                             
                                        </div>
                                   </li>
                              </ul>
                         </div>

<?php
    }
?>


     </div>
        </div>
 </div>

 <!-- FOOTER -->
        <h6 style="text-align: center;"> <?php include 'footer.php'; ?></h6> 
