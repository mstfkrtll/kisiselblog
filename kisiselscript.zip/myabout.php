<?php include 'header.php';



##HAKKIMDA TABLOSU

$hakkimda = $db->prepare("SELECT * FROM hakkimda");
$hakkimda->execute();
$hakkimdarow = $hakkimda->fetch(PDO::FETCH_ASSOC);


 ?>



     <div id="content" class="mt-2">
          <div class="container">

             <div class="row">
                    
                         <div class="card card-red widget" id="search-widget" >
                              <div class="card-header hakkimda" style="background: #F44336;">
                                   <i class="material-icons">assignment_ind</i>
                                   HAKKIMDA
                              </div>
                        <div class="col-lg-12" style="background: #f9f9f1; color: #444; padding-top: 10px;">
                              <div style="padding: 0;" class="container yazilarim-beyaz">
                              <div class="col-md-3" style="margin-top: 15px"><img width="100%" height="100%" style="margin-bottom: 10px;" src="images/<?php echo $hakkimdarow["hakkimda_foto"]; ?>"></div>
                                    <div class="col-md-9" style="margin-top: 10px;">
                                    <h5><?php echo $hakkimdarow["hakkimda_baslik"]; ?></h5>
                                    <p><?php echo $hakkimdarow["hakkimda_aciklama"]; ?></p></div>
                              </div>
                         </div>
                    </div>
               </div>         

  <h6 style="text-align: center;"> <?php include 'footer.php'; ?></h6> 