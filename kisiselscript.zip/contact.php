
 <div class="col-lg-4">
                         <div class="card card-warning widget" id="search-widget">
                              <div class="card-header"><i class="material-icons">mail</i>İletişim için </div>
                              <?php 

                                      if ($_POST){
                                          
                                          $adsoyad = $_POST["adsoyad"];
                                          $eposta = $_POST["eposta"];
                                          $konu = $_POST["konu"];
                                          $mesaj = $_POST["mesaj"];

                                          $mesajlar = $db->prepare("INSERT INTO mesajlar SET mesaj_gonderenisim=?, mesaj_konu=?, mesaj_aciklama=?, mesaj_gonderenmail=?");
                                          $mesajekle = $mesajlar->execute(array($adsoyad, $konu, $mesaj, $eposta));

                                          if ($mesajekle) {
                                              ?>

                                              <script type="text/javascript">
                                                   alert("Mesajınız Gönderildi!")
                                              </script>

                                              <?php
                                          }else{
                                              ?>

                                              <script type="text/javascript">
                                                   alert("Mesajınız gönderilirken bir hata oluştu!")
                                              </script>

                                              <?php
                                          }

                                      }
                                      ?>
                             
                              <ul class="list-group list-group-flush" >
                               <div class="col-md-12" style="background: #fff;">
                                  <form action="" method="post">
                                   <table>

                                   <tr>
                                   <label style="color: #888;">İsim :</label><br>
                                   <input name="adsoyad" style="width: 100%; border-radius: 5px; padding: 5px; border: 1px solid #ddd;" placeholder="Mustafa Kartal">
                                   </tr>
                                    <br>

                                   <tr>
                                   <label style="color: #888;">E-Posta :</label><br>
                                   <input name="eposta" style="width: 100%; border-radius: 5px; padding: 5px; border: 1px solid #ddd;" type="email" placeholder="mstfkrtll@yandex.com.tr">
                                    </tr>
                                    <br>

                                    <tr>
                                   <label style="color: #888;">Mesaj Konusu :</label><br>
                                   <input name="konu" style="width: 100%; border-radius: 5px; padding: 5px; border: 1px solid #ddd;" type="text" placeholder="Php dersleri...">
                                    </tr>
                                    <br>

                                    <tr>
                                   <label style="color: #888;">Mesajınız :</label><br>
                                   <textarea name="mesaj" style=" width: 100%; border-radius: 5px; padding: 5px; border: 1px solid #ddd;" rows="4" cols="22" placeholder="Mesajınız..."></textarea>
                                    </tr>

                                    <tr>
                                    <label></label><br>
                                   <input style=" width: 100%; border-radius: 5px; padding: 5px; border: 1px solid #2196F3; color: white; cursor: pointer; background: #2196F3; margin-bottom: 5px;" name="mesajgonder" type="submit" value="Mesaj Gönder">
                                   </tr>

                                    </table>
                                   </form>
                               
                                   </div>
                              </ul>
                              
                         </div>
                    </div>