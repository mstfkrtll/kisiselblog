     <?php include 'header.php'; ?>




     <div id="content" class="mt-2">
          <div class="container">
               <div class="row">
                    <div class="col-lg-4">
                         <div class="card card-warning widget" id="note-widget">
                              <div class="card-header">
                                   <i class="material-icons">list</i>
                                   Son Yazılar
                                   
                              </div>
                              <div class="card-block collapse" id="add_note">
                                   <button id="add" class="btn fab btn-warning"><i class="material-icons">send</i></button>
                                   <div id="note" contenteditable="true"></div>
                              </div>
                              <ul class="list-group list-group-flush">
                              <?php 

                              $yazilar = $db->prepare("SELECT * FROM yazilarim
                                   INNER JOIN kategoriler ON kategoriler.kat_id = yazilarim.yazi_kategori
                               ORDER BY yazi_id DESC LIMIT 10");
                              $yazilar->execute();
                              $yazi = $yazilar->fetchALL(PDO::FETCH_ASSOC);

                              foreach ($yazi as $yazicek) {
                                   ?>

                                   <a href="<?php echo $ayarrow["site_url"]; ?>content/<?php echo seo($yazicek["yazi_baslik"]).'/'.$yazicek["yazi_id"]; ?>" style="color: #777;"><li class="list-group-item"><?php echo substr($yazicek["yazi_baslik"],0,25); ?>... <div class="tag tag-pill tag-default" style="background: #FFC107; float: right;"><?php echo $yazicek["kat_isim"]; ?></div></li></a>

                                  <?php
                              }

                              ?>
                                
                              </ul>
                         </div>
                    </div>


                    <!-- İLETİŞİM BÖLÜMÜ -->
 
                    <?php include 'contact.php'; ?>

                    <!-- İLETİŞİM BÖLÜMÜ -->



                    <div class="col-lg-4">
                         <div class="card card-danger widget" id="logs-widget">
                              <div class="card-header"><i class="material-icons">comment</i> Son Yorumlar</div>
                              <ul class="list-group list-group-flush">
                              <?php 

                              $yorumlar = $db->prepare("SELECT * FROM yorumlar 
                                   INNER JOIN yazilarim ON yazilarim.yazi_id = yorumlar.yorum_konu_id
                                   ORDER BY yorum_id DESC LIMIT 4");
                              $yorumlar->execute();
                              $yorum = $yorumlar->fetchALL(PDO::FETCH_ASSOC);
                              $yorumsay = $yorumlar->rowCount();

                              if($yorumsay){

                              foreach($yorum as $yorumcek) {
                              ?>

                             <a href="<?php echo $ayarrow["site_url"]; ?>content/<?php echo seo($yorumcek["yazi_baslik"]).'/'.$yorumcek["yazi_id"]; ?>" style="text-decoration: none;"> <li class="list-group-item">
                                        <i class="material-icons icon">comment</i>
                                        <img width="50px" src="images/yazilarim/<?php echo $yorumcek["yazi_resim"];?>" alt="">
                                        <div class="content">
                                             <p><b><?php echo $yorumcek["yorum_ekleyen"]; ?></b>
                                                <em><?php echo mb_substr($yorumcek["yorum_icerik"],0,40); ?>...</em>
                                             </p>
                                             <p>
                                                  <small><?php echo $yorumcek["yazi_baslik"]; ?></small>
                                                  <small><?php echo timeAgo($yorumcek["yorum_tarih"]); ?></small>
                                             </p>
                                        </div>
                                   </li></a>

                              <?php

                    }


               }
                              ?>

                                   
                              </ul>
                         </div>
                    </div>
               </div>




          </div>
     </div>

  <h6 style="text-align: center;"> <?php include 'footer.php'; ?></h6> 