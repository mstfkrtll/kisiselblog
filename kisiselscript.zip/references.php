<?php include 'header.php'; ?>

   
     <div id="content" class="mt-2">
          <div class="container">  
               <div class="row">
                    <div class="card card-info widget" id="search-widget" style="background: #3F51B5; width: 100%;" >
                              <div class="card-header">
                                   <i class="material-icons">work</i>
                                   Referanslarım
                              </div>
               <div class="col-md-12" style="background: #f9f9f1; padding-top: 20px;">

<?php 

               $referanslar = $db->prepare("SELECT * FROM referanslar ORDER BY ref_id DESC");
               $referanslar->execute();
               $refcek = $referanslar->fetchALL(PDO::FETCH_ASSOC);
               $refsor = $referanslar->rowCount();

               if ($refsor) {
                   
                    foreach ($refcek as $refcekk) {
                        ?>

                     <div class="col-lg-4">
                         <a href=""><div class="card article">
                              <div class="card-cover">
                                   <img width="100%" height="100%" src="images/referanslar/<?php echo $refcekk["ref_resim"]; ?>">
                              </div>
                              <div class="card-block" style="text-align: center;">
                                   <a href="<?php echo $refcekk["ref_link"]; ?>" target="_blank"><h6><?php echo $refcekk["ref_baslik"]; ?></h6></a>
                                   <small><em><?php echo timeAgo($refcekk["ref_tarih"]); ?></em></small>
                              </div>
                              
                         </div>
                    </div>

                        <?php
                    }


               }


               ?>

               </div>
          </div>
          </div>
     </div>

     
 <h6 style="text-align: center;"> <?php include 'footer.php'; ?></h6> 