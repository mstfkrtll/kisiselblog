
<?php 
   
include 'sistem/ayar.php'; 
include 'sistem/tarih_fonksiyon.php';
include 'sistem/seourl.php';



?>

<!DOCTYPE html>
<html lang="en" style="background: url(<?php echo $ayarrow["site_url"]; ?>images/yenibg.jpg); background-size:cover;">
<head>
<link rel="icon" type="image/png" href="<?php echo $ayarrow["site_url"]; ?>images/<?php echo $ayarrow["site_favicon"]; ?>">
     <meta charset="UTF-8">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <meta http-equiv="X-UA-Compatible" content="ie=edge">
     <title><?php echo $ayarrow["site_title"]; ?></title>
     <meta name="description" content="<?php echo $ayarrow["site_url"]; ?><?php echo $ayarrow["site_desc"]; ?>">
     <meta name="keywords" content="<?php echo $ayarrow["site_url"]; ?><?php echo $ayarrow["site_keyw"]; ?>">


     <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:100,300,400,500,700,900">
     <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
     <link rel="stylesheet" href="<?php echo $ayarrow["site_url"]; ?>assets/plugins/bootstrap/css/bootstrap.min.css">
     <link rel="stylesheet" href="<?php echo $ayarrow["site_url"]; ?>assets/plugins/bootstrap/css/bootstrap-flex.min.css">
     <link rel="stylesheet" href="<?php echo $ayarrow["site_url"]; ?>assets/plugins/tether/css/tether.min.css">
     <link rel="stylesheet" href="<?php echo $ayarrow["site_url"]; ?>assets/plugins/jQueryFiler/css/jquery.filer.css">
     <link rel="stylesheet" href="<?php echo $ayarrow["site_url"]; ?>assets/plugins/toastr8/toastr8.min.css">
     <link rel="stylesheet" href="<?php echo $ayarrow["site_url"]; ?>assets/css/style.css">

     <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
     <!-- <link rel="stylesheet" href="assets/css/custom.css"> -->

 

</head>
<body style="background: url(<?php echo $ayarrow["site_url"]; ?>images/yenibg.jpg); background-size: 100%">

     <nav class="navbar navbar-light" id="menu">
          <div class="container">
               <div class="col-md-6"> </div>
               <div class="col-md-2"><a style="margin-left: -60px;" href="<?php echo $ayarrow["site_url"]; ?>" class="navbar-brand" >
               <img style="border: 2px solid #d4d4d4;" src="<?php echo $ayarrow["site_url"]; ?>images/<?php echo $hakkimdacek["hakkimda_foto"]; ?>" alt="">
               </a></div>
               <div class="col-md-4"></div>
               
              
              
          </div>
     </nav>
 <div style="clear:both"></div>

              <div class="container" style="text-align: center; text-shadow: 4px 4px 4px #444; margin-top: 10px;">
                              <a href="index" style="text-decoration: none;"><b style="color: #fff;">Mstfkrtll.com'a Hoşgeldiniz.</b><br>
                    <em><small style="color: #fff;">Geleceğe yatırım yap....</small></em></a>
               
          </div>

          <!-- şimdilik durucak -->
      <nav class="navbar navbar-light bg-faded" id="submenu" style="background: none;">
          
     </nav>
          <!-- sımdılık durucak -->


     <div class="container">

 <div class="row">

          <?php

               $menuler = $db->prepare("SELECT * FROM menuler");
               $menuler->execute();
               $menu = $menuler->fetchALL(PDO::FETCH_ASSOC);

               foreach ($menu as $menucek) {
                    ?>

                     <div class="col-lg-2" style="margin-bottom: 6px;" >
                         <a href="<?php echo $ayarrow["site_url"]; ?><?php echo $menucek["menu_link"]; ?>" style="text-decoration: none; "><div class="card card-teal mini-widget" style="margin: 0; color: #fff; background: <?php echo $menucek["menu_color"]; ?>;">
                              <i class="material-icons" style="color: #fff;"><?php echo $menucek["menu_icon"]; ?></i>
                              <div class="card-block" style="color: #fff;">
                                   <p class="lead"><?php echo $menucek["menu_isim"]; ?></p>
                                   <p class="count"><?php echo $menucek["menu_aciklama"]; ?></p>
                              </div>
                         </div></a>
                    </div>

                    <?php
               }

          ?>




                   

 </div>
 
</div>