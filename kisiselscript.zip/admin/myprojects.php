<?php include 'header.php'; 
if(!isset($_SESSION["admin_kadi"])){
    header("Location: login.php");
}
?>
        <!-- Main content -->
                <div class="content">
                    <div class="row">

                            <div class="col-sm-12 col-md-12">
                            <div style="float: right; padding: -5px;"><a href="projeekle.php"><button style="float: right; padding: 5px;" class="btn btn-success">Proje Ekle</button></a></div>
                                 <h3 style="font-weight: bolder; margin-top: 0"> PROJELERİM </h3> 

                                 <span>

                                        <?php   if (@$_GET['projeekle']=="yetersiz") { 

                                                echo "<span style='color: orange;'><em>Fotoğraf boyutu çok büyük!</em></span>";
                                                

                                                }elseif (@$_GET['projeekle']=="no") { 

                                                echo "<span style='color: red;'><em>Fotoğraf yüklenirken bir hata oluştu!</em></span>";

                                                }elseif (@$_GET['projeekle']=="noo") { 

                                                echo "<span style='color: red;'><em>Fotoğraff yüklenirken bir hata oluştu!</em></span>";

                                                }elseif (@$_GET['projeekle']=="yes") { 

                                                echo "<span style='color: green; float: left'><em>Proje başarıyla eklendi!</em></span>";

                                                }elseif (@$_GET['projeekle']=="gecersiz") { 

                                                echo "<span style='color: red;'><em>Dosya PNG veya JPG formatında olmalıdır!!</em></span>";

                                                }
                                    /*?>
                                            </span>
                                  
                                  <span>

                                        <?php  */ elseif (@$_GET['projeduzenle']=="yetersiz") { 

                                                echo "<span style='color: orange;'><em>Fotoğraf boyutu çok büyük!</em></span>";

                                                }elseif (@$_GET['projeduzenle']=="no") { 

                                                echo "<span style='color: red;'><em>Fotoğraf yüklenirken bir hata oluştu!</em></span>";

                                                }elseif (@$_GET['projeduzenle']=="noo") { 

                                                echo "<span style='color: red;'><em>Fotoğraf yüklenirken bir hata oluştu!</em></span>";

                                                }elseif (@$_GET['projeduzenle']=="yes") { 

                                                echo "<span style='color: green;'><em>Proje başarıyla güncellendi!</em></span>";

                                                }elseif (@$_GET['projeduzenle']=="gecersiz") { 

                                                echo "<span style='color: red;'><em>Dosya PNG veya JPG formatında olmalıdır!!</em></span>";

                                                }
                                   /* ?>
                                            </span>

              <span>

                                        <?php */  elseif (@$_GET['projesil']=="yes") { 

                                                echo "<span style='color: green;'><em>Proje başarıyla silindi!</em></span>";
                                                

                                                }elseif (@$_GET['projesil']=="no") { 

                                                echo "<span style='color: red;'><em>Proje silinirken bir hata oluştu!</em></span>";

                                                }
                                                
                                                ?>


                            </span>  
 <div style="clear: both;"></div>
<hr style="height: 2px; background: #ccc;">
                       </div>




  <div class="col-md-12">
  <div class="table-responsive">          
  <table class="table">
    <thead>
      <tr>
        <th style="text-align: center;" width="30">#</th>
        <th style="text-align: center;" width="120">Resim</th>
        <th style="text-align: center;" width="280">Link Demo</th>
        <th style="text-align: center;" width="450">Açıklama</th>
        <th style="text-align: center;">İşlemler</th>
      </tr>
    </thead>
    <tbody>
      <?php

      $projelerim = $db->prepare("SELECT * FROM projelerim
        ORDER BY proje_id DESC
        ");
      $projelerim->execute();
      $proje = $projelerim->fetchALL(PDO::FETCH_ASSOC);

      $projesay = $projelerim->rowCount();

      if ($projesay) {
        
        foreach ($proje as $projecek) {
            ?>
<tr>
            <td style="text-align: center;"><?php echo $projecek["proje_id"]; ?></td>
        <td style="text-align: center;"><img width="100%" height="70%" style="border-radius: 50%;" src="../images/projelerim/<?php echo $projecek["proje_resim"]; ?>"></td>
        <td style="text-align: center;"><a href="../../<?php echo $projecek["proje_link"]; ?>" target="_blank"><?php echo $projecek["proje_isim"]; ?></a></td>
        <td style="text-align: center;"><?php echo $projecek["proje_aciklama"]; ?></td>
        <td style="text-align: center;">
        <a href="projeduzenle.php?id=<?php echo $projecek["proje_id"]; ?>"><button  style="background: #1a426c; color: white; padding: 5px; border-radius: 5px; border: 1px solid #1a426c;" ><i class="fa fa-edit"></i>Düzenle</button></a>
        <a href="islem.php?proje_id=<?php echo $projecek["proje_id"]; ?>"><button  style="background: darkred; color: white; padding: 5px; border-radius: 5px; border: 1px solid darkred;" ><i class="fa fa-trash"></i>Sil&nbsp;</button></a>        
        </td>
 </tr>
            <?php
        }

      }


      ?>
        
     
    </tbody>
  </table>
  </div>       
</div>
<hr>
                                    
                                
                               
                            </div>
                        </div>


       <?php include 'footer.php'; ?>