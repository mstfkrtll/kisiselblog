<?php include 'header.php'; 
if(!isset($_SESSION["admin_kadi"])){
    header("Location: login.php");
}
?>
        <!-- Main content -->
                <div class="content">
                    <div class="row">

                            <div class="col-sm-12 col-md-12">
                                 <h3 style="font-weight: bolder;"> AYARLAR </h3> 
                                  <span>

                                        <?php   if (@$_GET['guncelle']=="yes") { 

                                                echo "<span style='color: green;'><em>Ayarlar başarıyla güncellendi!</em></span>";

                                                }elseif (@$_GET['guncelle']=="no") { 

                                                echo "<span style='color: red;'><em>Ayarlar, demo versiyon olduğu için güncellenemez!</em></span>";

                                                }
                                    ?>
                                            </span>

<hr style="height: 2px; background: #ccc;">
                       </div>


  <form action="islem.php" method="POST">


                    
                            <div class="col-sm-12 col-md-6">
                                <div class="form-group">
                                            <label for="exampleInputEmail1">Site Title  </label>
                                            <input type="text" class="form-control" name="title" value="<?php echo $ayarrow['site_title'];?>">
                                                
                                        </div>
                            </div>

                            <div class="col-sm-12 col-md-6">
                                <div class="form-group">
                                            <label for="exampleInputEmail1">Site Url  </label>
                                            <input type="text" class="form-control" name="url" value="<?php echo $ayarrow['site_url'];?>">
                                                
                                        </div>
                            </div>

                            <div class="col-sm-12 col-md-6">
                                <div class="form-group">
                                            <label for="exampleInputEmail1">Site Description  </label>
                                            <input type="text" class="form-control" name="desc" value="<?php echo $ayarrow['site_desc'];?>">
                                                
                                        </div>
                            </div>

                            <div class="col-sm-12 col-md-6">
                                <div class="form-group">
                                            <label for="exampleInputEmail1">Site Keywords  </label>
                                            <input type="text" class="form-control" name="keyw" value="<?php echo $ayarrow['site_keyw'];?>">
                                                
                                        </div>
                            </div>


                            <div class="col-sm-12 col-md-6">
                                <div class="form-group">
                                            <label for="exampleInputEmail1">Facebook Link  </label>
                                            <input type="text" class="form-control" name="facebook" value="<?php echo $ayarrow['site_facebook'];?>">
                                                
                                        </div>

                            </div>

                            <div class="col-sm-12 col-md-6">
                                <div class="form-group">
                                            <label for="exampleInputEmail1">Twitter Link  </label>
                                            <input type="text" class="form-control" name="twitter" value="<?php echo $ayarrow['site_twitter'];?>">
                                                
                                        </div>
                            </div>

                            <div class="col-sm-12 col-md-6">
                                <div class="form-group">
                                            <label for="exampleInputEmail1">Instagram Link  </label>
                                            <input type="text" class="form-control" name="instagram" value="<?php echo $ayarrow['site_instagram'];?>">
                                                
                                        </div>
                            </div>
                            
                            <div class="col-sm-12 col-md-6">
                                <div class="form-group">
                                            <label for="exampleInputEmail1">Pinterest Link  </label>
                                            <input type="text" class="form-control" name="pinterest" value="<?php echo $ayarrow['site_pinterest'];?>">
                                                
                                        </div>
                            </div>
                                        

<hr>
                                    
                                
                                <div class="col-sm-12 col-md-6">
                                        <div class="form-group">

                                        <input type="submit" name="settings" class="btn btn-success" value="Güncelle!">

                                    </div>
                                </div>

                                </form>





<!-- ADMİN AYARLAR -->
                                 <!-- <div class="col-sm-12 col-md-12">
                                 <h3 style="font-weight: bolder;">ADMİN AYARLAR </h3> 
                                  <span>

                                        <?php   if (@$_GET['adminguncelle']=="yes") { 

                                                echo "<span style='color: green;'><em>Admin bilgileri başarıyla güncellendi!</em></span>";

                                                }elseif (@$_GET['adminguncelle']=="no") { 

                                                echo "<span style='color: red;'><em>Admin bilgileri güncellenirken bir hata oluştu!</em></span>";

                                                }
                                    ?>
                                            </span>

<hr style="height: 2px; background: #ccc;">
                       </div>
                    <form action="islem.php?admin_id=<?php echo $id; ?>" method="POST ">

                    <div class="col-sm-12 col-md-6">
                                <div class="form-group">
                                            <label for="exampleInputEmail1">Kullanıcı Adı </label>
                                            <input type="text" class="form-control" name="admin_kadi" value="<?php echo $admincek['admin_kadi'];?>">
                                                
                                        </div>
                            </div>

                            <div class="col-sm-12 col-md-6">
                                <div class="form-group">
                                            <label for="exampleInputEmail1">Şifre</label>
                                            <input type="password" class="form-control" name="admin_sifre" value="<?php echo $admincek['admin_sifre'];?>">
                                                
                                        </div>
                            </div>




                       <div class="col-sm-12 col-md-6">
                                        <div class="form-group">

                                        <input type="submit" name="adminsettings" class="btn btn-success" value="Güncelle!">

                                    </div>
                                </div>
                                </form> -->
                               
                            </div>
                        </div>



       <?php include 'footer.php'; ?>


