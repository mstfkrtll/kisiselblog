<?php include 'header.php'; 
if(!isset($_SESSION["admin_kadi"])){
    header("Location: login.php");
}
?>

 <?php
                                    $id = @$_GET["id"];
                                    $yazilarim = $db->prepare("SELECT * FROM yazilarim 
                                        INNER JOIN kategoriler ON kategoriler.kat_id = yazilarim.yazi_kategori
                                    WHERE yazi_id=?");
                                    $yazilarim->execute(array($id));
                                    $yazicek = $yazilarim->fetch(PDO::FETCH_ASSOC);
?>

 


        <!-- Main content -->
                <div class="content">
                    <div class="row">

                        <div class="col-sm-12 col-md-12">
                                 <h3 style="font-weight: bolder;"> YAZI DÜZENLE </h3>

<hr style="height: 2px; background: #ccc;">
                       </div>

                        <div class="col-sm-12 col-md-12">
                        
                        <form action="islem.php?id=<?php echo $id; ?>" method="POST" enctype="multipart/form-data">
                        <div class="panel-body">

                        <div class="form-group row col-md-12">
                                        <label for="exampleInputFile" class="col-sm-2">Resim Seçin :</label>
                                        <div class="col-sm-9">
                                        <img width="150" height="150"  src="../images/yazilarim/<?php echo $yazicek["yazi_resim"]; ?>" alt="">
                                        </div>

                                    </div>
                                  
                                
                                    <div class="form-group row col-md-12">
                                        <label for="exampleInputFile" class="col-sm-2">Resim Seçin :</label>
                                        <div class="col-sm-9">
                                        
                                        <input class="form-control" type="file" name="yazi_resim">
                                        </div>

                                    </div>

                        <div class="form-group row col-md-12">
                        <label for="example-text-input" class="col-sm-2 col-form-label">Yazi Başlık :  </label>
                        <div class="col-sm-9">
                        <input class="form-control" name="yazi_baslik" value="<?php echo $yazicek["yazi_baslik"]; ?>" type="text" required="" placeholder="Lütfen kişi adını giriniz.">
                        </div>
                        </div>

                        <div class="form-group row col-md-12">
                        <label for="example-text-input" class="col-sm-2 col-form-label">Yazi Kategori :  </label>
                        <div class="col-sm-9">
                        <select class="form-control" name="yazi_kategori">
                            <?php

                                                $b = $db->prepare("SELECT * FROM kategoriler ORDER BY kat_id DESC");
                                                $b->execute(array());
                                                $c = $b->fetchALL(PDO::FETCH_ASSOC);

                                                foreach ($c as $k) {

                                                 echo '<option value="'.$k["kat_id"].'"';

                                                    echo $yazicek["yazi_kategori"] == $k["kat_id"] ? 'selected' : null;

                                                    echo '>'.$k["kat_isim"].'</option>';

                                                }

                                            ?>
                        </select>
                        </div>
                        </div>

                        <div class="form-group row col-md-12">
                        <label for="example-text-input" class="col-sm-2 col-form-label">Yazi Açıklama :  </label>
                        <div class="col-sm-9">
                        <textarea class="form-control" id="editor1" name="yazi_icerik" type="text" required=""><?php echo $yazicek["yazi_icerik"]; ?></textarea>
                        <script>
            // Ckeditor ü  ön tanımlı  ayarları  kullanarak <textarea id="editor1"> nesnesi üzerinde aktif  ediyoruz
            CKEDITOR.replace( 'editor1' );
        </script>
                        </div>
                        </div>
                        
                        <div class="form-group row col-md-12">
                        <input type="submit" name="mywritings" class="btn btn-success" value="Düzenle">
                        </div>
                        </div>
                        



                                    </div>

                                </div>
                        </div>


         <?php include 'footer.php'; ?>