 <!-- İŞLEMLER -->


<?php

/*DATABASE BAGLANTISI*/
include '../sistem/ayar.php';


## LOGİN İŞLEMİ
 
if(isset($_POST['loggin'])) {
 
 
$admin_kadi=$_POST['admin_kadi'];
$admin_sifre=md5($_POST['admin_sifre']);

 
if($admin_kadi && $admin_sifre){
 
 
	$query=$db->prepare("select * from admin where admin_kadi=? and admin_sifre=?");
	$query->execute(array($admin_kadi,$admin_sifre));
	$z = $query->fetch(PDO::FETCH_ASSOC);
	

	if ($z){
 
		$_SESSION["login"] 		= "true";
		$_SESSION['admin_kadi'] = $z["admin_kadi"];
		$_SESSION['admin_id'] 	= $z["admin_id"];
    
		header('Location:index.php');
  } else {
    
  //   echo 'giriş yapılamadı';
  //   exit;
  // }
 
  header('Location:login.php?login=no');
}
}
}	




/*SETTINGS İŞLEMLERİ */
 if (isset($_POST["settings"])) {

	
	$title 		= $_POST["title"];
	$url 		= $_POST["url"];
	$desc 		= $_POST["desc"];
	$keyw 		= $_POST["keyw"];
	$facebook 	= $_POST["facebook"];
	$twitter 	= $_POST["twitter"];
	$instagram 	= $_POST["instagram"];
	$pinterest 	= $_POST["pinterest"];


	$query = $db->prepare("UPDATE ayarlar SET 
/*site_url in r siyok onu koy*/
		site_title=?, site_ul=?, site_desc=?, site_keyw=?, site_facebook=?, site_twitter=?, site_instagram=?, site_pinterest=?");
	$ayarlarupdate = $query->execute(array($title,$url,$desc,$keyw,$facebook,$twitter,$instagram,$pinterest));

	if ($ayarlarupdate) {

		header("Location: settings.php?guncelle=yes");
		}else{
		header("Location: settings.php?guncelle=no");

		}

	

}



/*************************************************************************************************************************/



##HAKKIMIZDA İŞLEMİ

if (isset($_POST["myabout"])) {

	$hak_id 			= $_GET["id"];
	$hak_foto 			= $_POST["hak_foto"];
	$hak_baslik 		= $_POST["hak_baslik"];
	$hak_aciklama		= $_POST["hak_aciklama"];

	$hakkguncelle = $db->prepare("UPDATE hakkimda SET/*hakkimda_balik in ksi yok onu unutma*/ 
		hakkimda_foto=?, hakkimda_basli=?, hakkimda_aciklama=?
		WHERE hakkimda_id=?");
	$hakupdate = $hakkguncelle->execute(array($hak_foto, $hak_baslik, $hak_aciklama, $hak_id));

	if ($hakupdate) {
		header("Location: myabout.php?guncelle=yes&id=$id");
	}else{
		header("Location: myabout.php?guncelle=no&id=$id");
	}
}




/*****************************************************************************************************************/



## YAZI EKLEME

$Dturu 	= array("image/jpeg","image/jpg","image/png","image/x-png");
$Duzanti = array("jpeg","jpg","png","x-png");

if (isset($_POST["yazi_ekle"])) {

	

	$kaynak   = $_FILES["yazi_resim"]["tmp_name"];
	$resim    = $_FILES["yazi_resim"]["name"];
	$boyut    = $_FILES["yazi_resim"]["size"];
	$turu     = $_FILES["yazi_resim"]["type"];

	$yazi_baslik = $_POST["yazi_baslik"];
	$yazi_icerik = $_POST["yazi_icerik"];
	$yazi_kategori = $_POST["yazi_kategori"];
	


	$uzanti   = substr($resim,strpos($resim,'.')+1);
	$yeniAd   =	substr(uniqid(md5(rand())),0,35).'.'.$uzanti;

	$hedef = "../images/yazilarim/".$yeniAd;



	if ($kaynak){
		
		if (!in_array($turu, $Dturu) && !in_array($uzanti, $Duzanti)) {
			
			header("Location: mywritings.php?yaziekle=gecersiz");

		}elseif($boyut>5242880){

			header("Location: mywritings.php?yaziekle=yetersiz");

		}else{

			if (move_uploaded_file($kaynak, $hedef)) {

				$query = $db->prepare("INSERT INTO yazilarim SET yazi_baslik=?, yazi_resim=?, yazi_icerik=?, yazi_kategori=?");
				$insert = $query->execute(array($yazi_baslik,$yeniAd,$yazi_icerik, $yazi_kategori));

				if ($insert) {
					
					header("Location: mywritings.php?yaziekle=yes");

				}else{

					header("Location: mywritings.php?yaziekle=noe");

				}

			}else{

				header("Location: mywritings.php?yaziekle=noo");

			}

		}


	}else{

		header("Location: mywritings.php?yaziekle=no");


	}


}


## YAZI GUNCELLEME


if (isset($_POST["mywritings"])) {
 	
 	$yazi_id		= 	$_GET["id"]; 
    $yazi_baslik	=	$_POST['yazi_baslik'];
	$yazi_icerik	=	$_POST['yazi_icerik'];
	$yazi_kategori	=	$_POST['yazi_kategori'];
   

if ($_FILES["yazi_resim"]["size"] > 0) {
	
	$kaynak   = $_FILES["yazi_resim"]["tmp_name"];
	$resim    = $_FILES["yazi_resim"]["name"];
	$boyut    = $_FILES["yazi_resim"]["size"];
	$turu     = $_FILES["yazi_resim"]["type"];


	$yeniAd   =substr(uniqid(md5(rand())),0,35).$resim;

	$hedef = "../images/yazilarim/".$yeniAd;



	if ($kaynak){

		if($boyut>5242880){

			header("Location: mywritings.php?id=$yazi_id&yaziduzenle=yetersiz");

		}else{

			if (move_uploaded_file($kaynak, $hedef)) {

				$query = $db->prepare("UPDATE yazilarim SET yazi_baslik=?, yazi_resim=?, yazi_icerik=?, yazi_kategori=? WHERE yazi_id=?");
				$update = $query->execute(array($yazi_baslik,$yeniAd,$yazi_icerik,$yazi_kategori,$yazi_id));

				if ($update) { 


					header("Location: mywritings.php?id=$yazi_id&yaziduzenle=yes");

				}else{

					header("Location: mywritings.php?id=$yazi_id&yaziduzenle=noe");

				}

			}else{

				header("Location: mywritings.php?id=$yazi_id&yaziduzenle=noo");

			}

		}


	}else{

		header("Location: mywritings.php?id=$yazi_id&yaziduzenle=no");


	}


}else{



	$query = $db->prepare("UPDATE yazilarim SET yazi_baslik=?, yazi_icerik=?, yazi_kategori=? WHERE yazi_id=?");
	$update = $query->execute(array($yazi_baslik,$yazi_icerik,$yazi_kategori,$yazi_id));

				if ($update) { 

					header("Location: mywritings.php?id=$yazi_id&yaziduzenle=yes");

				}else{

					header("Location: mywritings.php?id=$yazi_id&yaziduzenle=noe");

				}

}

	

}



## YAZI SİLME İŞLEMİ
if(isset($_GET["yazi_id"])) {


	$query = $db->prepare("DELETE FROM yazilarim WHERE yazi_id = :id");
	$delete = $query->execute(array('id' => $_GET["yazi_id"]));



	if ($delete) {
		?>
		
		<?php
			header("Location: mywritings.php?yazisil=yes");
		}else{
			header("Location: mywritings.php?yazisil=no");
		}
	
}


/**************************************************************************************************/


## REFERANS EKLEME

$Dturu 	= array("image/jpeg","image/jpg","image/png","image/x-png");
$Duzanti = array("jpeg","jpg","png","x-png");

if (isset($_POST["ref_ekle"])) {

	

	$kaynak   = $_FILES["ref_resim"]["tmp_name"];
	$resim    = $_FILES["ref_resim"]["name"];
	$boyut    = $_FILES["ref_resim"]["size"];
	$turu     = $_FILES["ref_resim"]["type"];

	$ref_baslik = $_POST["ref_baslik"];
	$ref_link 	= $_POST["ref_link"];
	


	$uzanti   = substr($resim,strpos($resim,'.')+1);
	$yeniAd   =	substr(uniqid(md5(rand())),0,35).'.'.$uzanti;

	$hedef = "../images/referanslar/".$yeniAd;



	if ($kaynak){
		
		if (!in_array($turu, $Dturu) && !in_array($uzanti, $Duzanti)) {
			
			header("Location: references.php?referansekle=gecersiz");

		}elseif($boyut>5242880){

			header("Location: references.php?referansekle=yetersiz");

		}else{

			if (move_uploaded_file($kaynak, $hedef)) {

				$query = $db->prepare("INSERT INTO referanslar SET ref_baslik=?, ref_link=?, ref_resim=?");
				$insert = $query->execute(array($ref_baslik,$ref_link,$yeniAd));

				if ($insert) {
					
					header("Location: references.php?referansekle=yes");

				}else{

					header("Location: references.php?referansekle=noe");

				}

			}else{

				header("Location: references.php?referansekle=noo");

			}

		}


	}else{

		header("Location: references.php?referansekle=no");


	}


}


## REFERANS GUNCELLEME


if (isset($_POST["references"])) {
 	
 	$ref_id		= 	$_GET["id"]; 
    $ref_baslik	=	$_POST['ref_baslik'];
	$ref_link	=	$_POST['ref_link'];
   

if ($_FILES["ref_resim"]["size"] > 0) {
	
	$kaynak   = $_FILES["ref_resim"]["tmp_name"];
	$resim    = $_FILES["ref_resim"]["name"];
	$boyut    = $_FILES["ref_resim"]["size"];
	$turu     = $_FILES["ref_resim"]["type"];


	$yeniAd   =substr(uniqid(md5(rand())),0,35).$resim;

	$hedef = "../images/referanslar/".$yeniAd;



	if ($kaynak){

		if($boyut>5242880){

			header("Location: references.php?id=$ref_id&referansduzenle=yetersiz");

		}else{

			if (move_uploaded_file($kaynak, $hedef)) {

				$query = $db->prepare("UPDATE referanslar SET ref_baslik=?, ref_link=?, ref_resim=? WHERE ref_id=?");
				$update = $query->execute(array($ref_baslik,$ref_link,$yeniAd,$ref_id));

				if ($update) { 


					header("Location: references.php?id=$ref_id&referansduzenle=yes");

				}else{

					header("Location: references.php?id=$ref_id&referansduzenle=noe");

				}

			}else{

				header("Location: references.php?id=$ref_id&referansduzenle=noo");

			}

		}


	}else{

		header("Location: references.php?id=$ref_id&referansduzenle=no");


	}


}else{



	$query = $db->prepare("UPDATE referanslar SET ref_baslik=?, ref_link=? WHERE ref_id=?");
	$update = $query->execute(array($ref_baslik,$ref_link,$ref_id));

				if ($update) { 

					header("Location: references.php?id=$ref_id&referansduzenle=yes");

				}else{

					header("Location: references.php?id=$ref_id&referansduzenle=noe");

				}

}

	

}


## REFERANS SİLME İŞLEMİ
if(isset($_GET["ref_id"])) {


	$query = $db->prepare("DELETE FROM referanslar WHERE ref_id = :id");
	$delete = $query->execute(array('id' => $_GET["ref_id"]));

	if ($delete) {
			header("Location: references.php?refsil=yes");
		}else{
			header("Location: references.php?refsil=no");
		}
	
}




/*********************************************************************************************************/




## KATEGORİ EKLEME

$Dturu 	= array("image/jpeg","image/jpg","image/png","image/x-png");
$Duzanti = array("jpeg","jpg","png","x-png");

if (isset($_POST["kat_ekle"])) {

	

	$kaynak   = $_FILES["kat_resim"]["tmp_name"];
	$resim    = $_FILES["kat_resim"]["name"];
	$boyut    = $_FILES["kat_resim"]["size"];
	$turu     = $_FILES["kat_resim"]["type"];

	$kat_baslik = $_POST["kat_baslik"];
	


	$uzanti   = substr($resim,strpos($resim,'.')+1);
	$yeniAd   =	substr(uniqid(md5(rand())),0,35).'.'.$uzanti;

	$hedef = "../images/kategoriler/".$yeniAd;



	if ($kaynak){
		
		if (!in_array($turu, $Dturu) && !in_array($uzanti, $Duzanti)) {
			
			header("Location: categories.php?kategoriekle=gecersiz");

		}elseif($boyut>5242880){

			header("Location: categories.php?kategoriekle=yetersiz");

		}else{

			if (move_uploaded_file($kaynak, $hedef)) {

				$query = $db->prepare("INSERT INTO kategoriler SET kat_isim=?, kat_resim=?");
				$insert = $query->execute(array($kat_baslik,$yeniAd));

				if ($insert) {
					
					header("Location: categories.php?kategoriekle=yes");

				}else{

					header("Location: categories.php?kategoriekle=noe");

				}

			}else{

				header("Location: categories.php?kategoriekle=noo");

			}

		}


	}else{

		header("Location: categories.php?kategoriekle=no");


	}


}




## KATEGORİ GUNCELLEME


if (isset($_POST["categories"])) {
 	
 	$kat_id		= 	$_GET["id"]; 
    $kat_baslik	=	$_POST['kat_baslik'];
   

if ($_FILES["kat_resim"]["size"] > 0) {
	
	$kaynak   = $_FILES["kat_resim"]["tmp_name"];
	$resim    = $_FILES["kat_resim"]["name"];
	$boyut    = $_FILES["kat_resim"]["size"];
	$turu     = $_FILES["kat_resim"]["type"];


	$yeniAd   =substr(uniqid(md5(rand())),0,35).$resim;

	$hedef = "../images/kategoriler/".$yeniAd;



	if ($kaynak){

		if($boyut>5242880){

			header("Location: categories.php?id=$kat_id&kategoriduzenle=yetersiz");

		}else{

			if (move_uploaded_file($kaynak, $hedef)) {

				$query = $db->prepare("UPDATE kategoriler SET kat_isim=?, kat_resim=? WHERE kat_id=?");
				$update = $query->execute(array($kat_baslik,$yeniAd,$kat_id));

				if ($update) { 


					header("Location: categories.php?id=$kat_id&kategoriduzenle=yes");

				}else{

					header("Location: categories.php?id=$kat_id&kategoriduzenle=noe");

				}

			}else{

				header("Location: categories.php?id=$kat_id&kategoriduzenle=noo");

			}

		}


	}else{

		header("Location: categories.php?id=$kat_id&kategoriduzenle=no");


	}


}else{



	$query = $db->prepare("UPDATE kategoriler SET kat_isim=? WHERE kat_id=?");
	$update = $query->execute(array($kat_baslik,$kat_id));

				if ($update) { 

					header("Location: categories.php?id=$kat_id&kategoriduzenle=yes");

				}else{

					header("Location: categories.php?id=$kat_id&kategoriduzenle=noe");

				}

}

	

}


## KATEGORİ SİLME İŞLEMİ
if(isset($_GET["kat_id"])) {


	$query = $db->prepare("DELETE FROM kategoriler WHERE kat_id = :id");
	$delete = $query->execute(array('id' => $_GET["kat_id"]));

	if ($delete) {
			header("Location: categories.php?katsil=yes");
		}else{
			header("Location: categories.php?katsil=no");
		}
	
}




/*********************************************************************************************************/




## PROJE EKLEME

$Dturu 	= array("image/jpeg","image/jpg","image/png","image/x-png");
$Duzanti = array("jpeg","jpg","png","x-png");

if (isset($_POST["proje_ekle"])) {


	$proje_isim = $_POST["proje_isim"];
	

	$kaynak   = $_FILES["proje_resim"]["tmp_name"];
	$resim    = $_FILES["proje_resim"]["name"];
	$boyut    = $_FILES["proje_resim"]["size"];
	$turu     = $_FILES["proje_resim"]["type"];

	$proje_link = $_POST["proje_link"];
	$proje_aciklama = $_POST["proje_aciklama"];
	


	$uzanti   = substr($resim,strpos($resim,'.')+1);
	$yeniAd   =	substr(uniqid(md5(rand())),0,35).'.'.$uzanti;

	$hedef = "../images/projelerim/".$yeniAd;



	if ($kaynak){
		
		if (!in_array($turu, $Dturu) && !in_array($uzanti, $Duzanti)) {
			
			header("Location: myprojects.php?projeekle=gecersiz");

		}elseif($boyut>5242880){

			header("Location: myprojects.php?projeekle=yetersiz");

		}else{

			if (move_uploaded_file($kaynak, $hedef)) {

				$query = $db->prepare("INSERT INTO projelerim SET proje_isim=?, proje_resim=?, proje_link=?, proje_aciklama=?");
				$insert = $query->execute(array($proje_isim,$yeniAd,$proje_link,$proje_aciklama));

				if ($insert) {
					
					header("Location: myprojects.php?projeekle=yes");

				}else{

					header("Location: myprojects.php?projeekle=noe");

				}

			}else{

				header("Location: myprojects.php?projeekle=noo");

			}

		}


	}else{

		header("Location: myprojects.php?projeekle=no");


	}


}




## PROJE GUNCELLEME


if (isset($_POST["myprojects"])) {
 	
 	$proje_id		= 	$_GET["id"]; 
    $proje_isim		=	$_POST['proje_isim'];
    $proje_link		=	$_POST['proje_link'];
    $proje_aciklama	=	$_POST['proje_aciklama'];
   

if ($_FILES["proje_resim"]["size"] > 0) {
	
	$kaynak   = $_FILES["proje_resim"]["tmp_name"];
	$resim    = $_FILES["proje_resim"]["name"];
	$boyut    = $_FILES["proje_resim"]["size"];
	$turu     = $_FILES["proje_resim"]["type"];


	$yeniAd   =substr(uniqid(md5(rand())),0,35).$resim;

	$hedef = "../images/projelerim/".$yeniAd;



	if ($kaynak){

		if($boyut>5242880){

			header("Location: myprojects.php?id=$proje_id&projeduzenle=yetersiz");

		}else{

			if (move_uploaded_file($kaynak, $hedef)) {

				$query = $db->prepare("UPDATE projelerim SET proje_isim=?, proje_resim=?, proje_link=?, proje_aciklama=? WHERE proje_id=?");
				$update = $query->execute(array($proje_isim,$yeniAd,$proje_link,$proje_aciklama,$proje_id));

				if ($update) { 


					header("Location: myprojects.php?id=$proje_id&projeduzenle=yes");

				}else{

					header("Location: myprojects.php?id=$proje_id&projeduzenle=noe");

				}

			}else{

				header("Location: myprojects.php?id=$proje_id&projeduzenle=noo");

			}

		}


	}else{

		header("Location: myprojects.php?id=$proje_id&projeduzenle=no");


	}


}else{



	$query = $db->prepare("UPDATE projelerim SET proje_isim=?, proje_link=?, proje_aciklama=? WHERE proje_id=?");
	$update = $query->execute(array($proje_isim,$proje_link,$proje_aciklama,$proje_id));

				if ($update) { 

					header("Location: myprojects.php?id=$proje_id&projeduzenle=yes");

				}else{

					header("Location: myprojects.php?id=$proje_id&projeduzenle=noe");

				}

}

	

}


## PROJE SİLME İŞLEMİ
if(isset($_GET["proje_id"])) {


	$query = $db->prepare("DELETE FROM projelerim WHERE proje_id = :id");
	$delete = $query->execute(array('id' => $_GET["proje_id"]));

	if ($delete) {
			header("Location: myprojects.php?projesil=yes");
		}else{
			header("Location: myprojects.php?projesil=no");
		}
	
}


/*********************************************************************************************************/




## YORUM DUZENLEME

if (isset($_POST["comments"])) {

	$id = $_GET["yorumid"];

	$yorum_ekleyen 	= $_POST["yorum_ekleyen"];
	$yorum_eposta 	= $_POST["yorum_eposta"];
	$yorum_icerik 	= $_POST["yorum_icerik"];
	$yorum_islem	= $_POST["yorum_islem"];

	$yorumguncelle = $db->prepare("UPDATE yorumlar SET 
		yorum_ekleyen=?, yorum_eposta=?, yorum_icerik=?, yorum_durum=?
		WHERE yorum_id=?");
	$yorumupdate = $yorumguncelle->execute(array($yorum_ekleyen, $yorum_eposta, $yorum_icerik, $yorum_islem, $id));

	if ($yorumupdate) {
		header("Location: comments.php?duzenle=yes&id=$id");
	}else{
		header("Location: comments.php?duzenle=no&id=$id");
	}
}







## YORUM SİLME
if(isset($_GET["yorum_id"])) {


  $query = $db->prepare("DELETE FROM yorumlar WHERE yorum_id = :id");
  $delete = $query->execute(array('id' => $_GET["yorum_id"]));


  if ($delete) {
  	?>
  	<script type="text/javascript">
  		alert("Yorum silinsin mi ?");
  	</script>

  	<?php

      header('refresh:0.001; url=comments.php?commentsil=yes');
    }else{
      header("refresh:0.001; url=comments.php?commentsil=no");
    }
  
}




## MESAJ SİLME
if(isset($_GET["mesajsil"])) {


  $query = $db->prepare("DELETE FROM mesajlar WHERE mesaj_id = :id");
  $delete = $query->execute(array('id' => $_GET["mesajsil"]));


  if ($delete) {
  	?>
  	<script type="text/javascript">
  		alert("Mesaj silinsin mi ?");
  	</script>

  	<?php

      header('refresh:0.001; url=messages.php?mesajsil=yes');
    }else{
      header("refresh:0.001; url=messages.php?mesajsil=no");
    }
  
}




## ADMİN GUNCELLE DUZENLEME
if($_SESSION){

	$admin_id = @$_GET["admin_id"];

if($_SESSION["admin_id"] == $admin_id){

	$admin = $db->prepare("SELECT * FROM admin WHERE admin_id=?");
			$admin->execute(array($admin_id));
			$admincek = $admin->fetch(PDO::FETCH_ASSOC);
			$adminsay = $admin->rowCount();

	if($adminsay){

if ($_POST) {


	$admin_kadi 	= $_POST["admin_kadi"];
	$admin_sifre 	= md5($_POST["admin_sifre"]);

	$adminguncelle = $db->prepare("UPDATE admin SET 
		admin_kadi=?, admin_sifre=? WHERE admin_id=?");
	$adminupdate = $adminguncelle->execute(array($admin_kadi, $admin_sifre, $_SESSION["admin_id"]));

	if ($adminupdate) {
		header("Location: settings.php?guncelle=yes&id=$id");
	}else{
		header("Location: settings.php?guncelle=no&id=$id");
	}
}

}

}

}

?>


