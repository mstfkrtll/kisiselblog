<?php include 'header.php';
if(!isset($_SESSION["admin_kadi"])){
    header("Location: login.php");
}
?>
        <!-- Main content -->
                <div class="content">
                    <div class="row">

                            <div class="col-sm-12 col-md-12">
                                 <h3 style="font-weight: bolder; margin-top: 0"> GELEN MESAJLAR </h3> 

                                  <span>

                                        <?php  if (@$_GET['mesajsil']=="yes") { 

                                                echo "<span style='color: green;'><em>Mesaj başarıyla silindi!</em></span>";
                                                

                                                }elseif (@$_GET['mesajsil']=="no") { 

                                                echo "<span style='color: red;'><em>Mesaj silinirken bir hata oluştu!</em></span>";

                                                }
                                                
                                                ?>


                            </span>
                           
                            <div style="clear: both;"></div>                 
<hr style="height: 2px; background: #ccc;">
                       </div>


                      


<div class="col-md-12">

      <?php 
        if ($_SESSION) {

                              $mesajlar = $db->prepare("SELECT * FROM mesajlar ORDER BY mesaj_id DESC");
                              $mesajlar->execute(array());
                              $mesaj = $mesajlar->fetchALL(PDO::FETCH_ASSOC);
                              $mesajsay = $mesajlar->rowCount();

                              if($mesajsay){

                              foreach($mesaj as $mesajcek) {


                                if($mesajcek["mesaj_okunma"]==1){

                              ?> 
 								<div style="margin-bottom: 5px;">
                                        <a href="messageread.php?id=<?php echo $mesajcek["mesaj_id"]; ?>" style="color: #ccc;">
	                                        <div class="list-group-item " style="border:1px solid #ccc;"><!-- mesaj okunduysa gri gozuksun -->
	                                                  <p class="fullname"><b><?php echo $mesajcek["mesaj_gonderenisim"]; ?></b>
                                                    <span class="time" style="float: right;"><?php echo timeAgo($mesajcek["mesaj_tarihi"]); ?></span></p>
	                                                  <p class="message"><em>Mesaj okundu...</em></p>
	                                                  <small class="email" style="color: #ccc;"><?php echo $mesajcek["mesaj_gonderenmail"]; ?></small>
	                                        </div>
                                        </a>
                                        
                                   </div>
                                   <?php
                                 }else{
                                  ?>

                                  <div style="margin-bottom: 5px;">
                                        <a href="messageread.php?id=<?php echo $mesajcek["mesaj_id"]; ?>" style="color: #444;">
                                          <div class="list-group-item " style="border:1px solid #444;"><!-- mesaj okunmadıysa siyah gozuksun -->
                                                    <p class="fullname"><b><?php echo $mesajcek["mesaj_gonderenisim"]; ?></b><span class="time" style="float: right;"><?php echo timeAgo($mesajcek["mesaj_tarihi"]); ?></span></p>
                                                    <p class="message"><em>1 yeni mesajınız var! Okumak için tıklayınız...</em></p>
                                                    <small class="email" style="color: #444;"><?php echo $mesajcek["mesaj_gonderenmail"]; ?></small>
                                          </div>
                                        </a>
                                        
                                   </div>

                                  <?php
                                 }
                                 
        }

      }

}
      ?>
        </div>  
</div>
<hr>
                                  

                               
                            </div>




       <?php include 'footer.php'; ?>

