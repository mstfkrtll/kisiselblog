<?php include 'header.php'; ?>

<?php
if(!isset($_SESSION["admin_kadi"])){
    header("Location: login.php");
}

?>
        <div class="content">
            <div class="container-fluid">

            
                <div class="row">
                <div class="col-sm-12 col-md-12" >
                                 <h3 style="font-weight: bolder; margin-top: 0; text-align: center;"> HIZLI KISAYOLLAR </h3> 
                                 <hr style="height: 2px; background: #ccc;">
                </div>
                    <div class="col-md-2">
                        <a href="settings.php"><div class="card" style="background: #dd4a53">
                            <div class="header" style="text-align: center;">
                                <h4 class="title" style="color: white; font-size: 70px"><i class="pe-7s-config"></i></h4>
                                <p class="category" style="color: white; font-weight: bolder; font-size: 17px">SETTINGS</p>
                            </div>
                        </div></a>
                    </div>

                    <div class="col-md-2">
                        <a href="myabout.php"><div class="card" style="background: #dd4a53">
                            <div class="header" style="text-align: center;">
                                <h4 class="title" style="color: white; font-size: 70px"><i class="pe-7s-info"></i></h4>
                                <p class="category" style="color: white; font-weight: bolder; font-size: 17px">MY ABOUT</p>
                            </div>
                        </div></a>
                    </div>

                    <div class="col-md-2">
                        <a href="mywritings.php"><div class="card" style="background: #dd4a53">
                            <div class="header" style="text-align: center;">
                                <h4 class="title" style="color: white; font-size: 70px"><i class="pe-7s-note2"></i></h4>
                                <p class="category" style="color: white; font-weight: bolder; font-size: 17px">MY WRITINGS</p>
                            </div>
                        </div></a>
                    </div>

                    <div class="col-md-2">
                        <a href="references.php"><div class="card" style="background: #dd4a53">
                            <div class="header" style="text-align: center;">
                                <h4 class="title" style="color: white; font-size: 70px"><i class="pe-7s-portfolio"></i></h4>
                                <p class="category" style="color: white; font-weight: bolder; font-size: 17px">REFERENCES</p>
                            </div>
                        </div></a>
                    </div>

                    <div class="col-md-2">
                        <a href="categories.php"><div class="card" style="background: #dd4a53">
                            <div class="header" style="text-align: center;">
                                <h4 class="title" style="color: white; font-size: 70px"><i class="pe-7s-pin"></i></h4>
                                <p class="category" style="color: white; font-weight: bolder; font-size: 17px">CATEGORIES</p>
                            </div>
                        </div></a>
                    </div>

                    <div class="col-md-2">
                        <a href="myprojects.php"><div class="card" style="background: #dd4a53">
                            <div class="header" style="text-align: center;">
                                <h4 class="title" style="color: white; font-size: 70px"><i class="pe-7s-coffee"></i></h4>
                                <p class="category" style="color: white; font-weight: bolder; font-size: 17px">MY PROJECTS</p>
                            </div>
                        </div></a>
                    </div>

                    <div class="col-md-2">
                        <a href="comments.php"><div class="card" style="background: #dd4a53">
                            <div class="header" style="text-align: center;">
                                <h4 class="title" style="color: white; font-size: 70px"><i class="pe-7s-comment"></i></h4>
                                <p class="category" style="color: white; font-weight: bolder; font-size: 17px">COMMENTS</p>
                            </div>
                        </div></a>
                    </div>

                    <div class="col-md-2">
                        <a href="messages.php"><div class="card" style="background: #dd4a53">
                            <div class="header" style="text-align: center;">
                                <h4 class="title" style="color: white; font-size: 70px"><i class="pe-7s-mail"></i></h4>
                                <p class="category" style="color: white; font-weight: bolder; font-size: 17px">MESSAGES</p>
                            </div>
                        </div></a>
                    </div>

                    
                </div>

                
            </div>
        </div>


      <?php include 'footer.php'; ?>