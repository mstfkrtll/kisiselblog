<?php include 'header.php'; 
if(!isset($_SESSION["admin_kadi"])){
    header("Location: login.php");
}
?>

 <?php
                                    $id = @$_GET["id"];
                                    $projelerim = $db->prepare("SELECT * FROM projelerim WHERE proje_id=?");
                                    $projelerim->execute(array($id));
                                    $projecek = $projelerim->fetch(PDO::FETCH_ASSOC);
?>

 


        <!-- Main content -->
                <div class="content">
                    <div class="row">

                        <div class="col-sm-12 col-md-12">
                                 <h3 style="font-weight: bolder;"> PROJE DÜZENLE </h3>

<hr style="height: 2px; background: #ccc;">
                       </div>

                        <div class="col-sm-12 col-md-12">
                        
                        <form action="islem.php?id=<?php echo $id; ?>" method="POST" enctype="multipart/form-data">
                        <div class="panel-body">

                        <div class="form-group row col-md-12">
                                        <label for="exampleInputFile" class="col-sm-2">Resim Seçin :</label>
                                        <div class="col-sm-9">
                                        <img width="150" height="100"  src="../images/projelerim/<?php echo $projecek["proje_resim"]; ?>" alt="<?php echo $projecek["proje_isim"]; ?>">
                                        </div>

                                    </div>
                                  
                                
                                    <div class="form-group row col-md-12">
                                        <label for="exampleInputFile" class="col-sm-2">Resim Seçin :</label>
                                        <div class="col-sm-9">
                                        
                                        <input class="form-control" type="file" name="proje_resim">
                                        </div>

                                    </div>

                        <div class="form-group row col-md-12">
                        <label for="example-text-input" class="col-sm-2 col-form-label">Proje İsmi :  </label>
                        <div class="col-sm-9">
                        <input class="form-control" name="proje_isim" value="<?php echo $projecek["proje_isim"]; ?>" type="text" required="" placeholder="Lütfen kişi adını giriniz.">
                        </div>
                        </div>

                        <div class="form-group row col-md-12">
                        <label for="example-text-input" class="col-sm-2 col-form-label">Proje Link :  </label>
                        <div class="col-sm-9">
                        <input class="form-control" name="proje_link" type="text" value="<?php echo $projecek["proje_link"]; ?>" required="">
                        
                        </div>
                        </div>

                       
                        <div class="form-group row col-md-12">
                        <label for="example-text-input" class="col-sm-2 col-form-label">Proje Açıklama :  </label>
                        <div class="col-sm-9">
                        <input class="form-control" name="proje_aciklama" type="text" value="<?php echo $projecek["proje_aciklama"]; ?>" required="">
                        
                        </div>
                        </div>
                        
                        <div class="form-group row col-md-12">
                        <input type="submit" name="myprojects" class="btn btn-success" value="Düzenle">
                        </div>
                        </div>
                        



                                    </div>

                                </div>
                        </div>


         <?php include 'footer.php'; ?>