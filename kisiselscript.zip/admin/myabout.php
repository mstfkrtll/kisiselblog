<?php include 'header.php'; 
if(!isset($_SESSION["admin_kadi"])){
    header("Location: login.php");
}
?>

        <!-- Main content -->
                <div class="content">
                    <div class="row">

                            <div class="col-sm-12 col-md-12">
                                 <h3 style="font-weight: bolder; margin-top:0"> HAKKIMDA </h3> 
                                  <span>

                                        <?php   if (@$_GET['guncelle']=="yes") { 

                                                echo "<span style='color: green;'><em>Hakkımda ayarları başarıyla güncellendi!</em></span>";

                                                }elseif (@$_GET['guncelle']=="no") { 

                                                echo "<span style='color: red;'><em> Hakkımda ayarları, demo versiyon olduğu için güncellenemez!</em></span>";

                                                }
                                    ?>
                                            </span>

<hr style="height: 2px; background: #ccc;">
                       </div>
<!-- <?php

##HAKKIMIZDA İŞLEMİ

if (isset($_POST["myabout"])) {

    $hak_foto           = $_POST["hak_foto"];
    $hak_baslik         = $_POST["hak_baslik"];
    $hak_aciklama       = $_POST["hak_aciklama"];

    $hakkguncelle = $db->prepare("UPDATE hakkimda SET 
        hakkimda_foto=?, hakkimda_baslik=?, hakkimda_aciklama=?");
    $hakupdate = $hakkguncelle->execute(array($hak_foto, $hak_baslik, $hak_aciklama,));

    if ($hakupdate) {
        echo "<script type='text/javascript'>
            sweetAlert('Tebrikler','Hakkında başarıyla güncellendi','success');
            </script>";
            header("location: settings.php");
    }else{
       echo '<script type="text/javascript">
            sweetAlert("Hata","Hakkında güncellenirken bir sorun oluştu!","error");
        </script>';
    }
}

?> -->

  <form action="islem.php?id=<?php echo $id; ?>" method="POST">
                                        <div class="col-sm-12 col-md-   ">
                                            <label for="exampleInputEmail1">Şuanki Resim :  </label>
                                            <div>
                                                <img width="100" src="../images/<?php echo $hakkimdacek['hakkimda_foto'];?>">
                                            </div>
                                     
                                        </div>

                            <div class="col-sm-12 col-md-6">
                                <div class="form-group">
                                            <label for="exampleInputEmail1">Resim :  </label>
                                            <input type="text" class="form-control" name="hak_foto" value="<?php echo $hakkimdacek["hakkimda_foto"]; ?>">
                                                
                                        </div>
                            </div>

                            <div class="col-sm-12 col-md-6">
                                <div class="form-group">
                                            <label for="exampleInputEmail1">Başlık :  </label>
                                            <input type="text" class="form-control" name="hak_baslik" value="<?php echo $hakkimdacek['hakkimda_baslik'];?>">
                                                
                                        </div>
                            </div>

                            <div class="col-sm-12 col-md-12">
                                <div class="form-group">
                                            <label for="exampleInputEmail1">Açıklama :  </label>
                                            <textarea id="editor1" name="hak_aciklama"><?php echo $hakkimdacek['hakkimda_aciklama'];?></textarea>
                                                 <script>
            // Ckeditor ü  ön tanımlı  ayarları  kullanarak <textarea id="editor1"> nesnesi üzerinde aktif  ediyoruz
            CKEDITOR.replace( 'editor1' );
        </script>
                                        </div>
                            </div>


                                        

<hr>
                                    
                                
                                <div class="col-sm-12 col-md-6">
                                        <div class="form-group">

                                        <input type="submit" name="myabout" class="btn btn-success" value="Güncelle!">

                                    </div>
                                </div>

                                </form>
                                
                               
                            </div>
                        </div>


         <?php include 'footer.php'; ?>