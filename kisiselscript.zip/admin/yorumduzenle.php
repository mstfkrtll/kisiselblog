<?php include 'header.php'; 
if(!isset($_SESSION["admin_kadi"])){
    header("Location: login.php");
}
?>
 <?php
                                    $id = @$_GET["id"];
                                    $yorumlar = $db->prepare("SELECT * FROM yorumlar WHERE yorum_id=?");
                                    $yorumlar->execute(array($id));
                                    $yorumcek = $yorumlar->fetch(PDO::FETCH_ASSOC);
?>



        <!-- Main content -->
                <div class="content">
                    <div class="row">

                        <div class="col-sm-12 col-md-12">
                                 <h3 style="font-weight: bolder; margin-top: 0"> YORUM DÜZENLE </h3>
                                

<hr style="height: 2px; background: #ccc;">
                       </div>

                        <div class="col-sm-12 col-md-12">
                        
                        <form action="islem.php?yorumid=<?php echo $id; ?>" method="POST" enctype="multipart/form-data">
                        <div class="panel-body">

                                    
                        <div class="form-group row col-md-12">
                        <label for="example-text-input" class="col-sm-2 col-form-label">Yorum Ekleyen :  </label>
                        <div class="col-sm-9">
                        <input class="form-control" name="yorum_ekleyen" value="<?php echo $yorumcek["yorum_ekleyen"]; ?>" type="text" >
                        </div>
                        </div>

                        <div class="form-group row col-md-12">
                        <label for="example-text-input" class="col-sm-2 col-form-label">Ekleyen E-posta :  </label>
                        <div class="col-sm-9">
                        <input class="form-control" name="yorum_eposta" value="<?php echo $yorumcek["yorum_eposta"]; ?>" type="text" >
                        </div>
                        </div>

                        <div class="form-group row col-md-12">
                        <label for="example-text-input" class="col-sm-2 col-form-label">Yorum İçerik :  </label>
                        <div class="col-sm-9">
                        <textarea class="form-control" id="editor1" name="yorum_icerik" type="text"><?php echo $yorumcek["yorum_icerik"]; ?></textarea>
                           <script>
            // Ckeditor ü  ön tanımlı  ayarları  kullanarak <textarea id="editor1"> nesnesi üzerinde aktif  ediyoruz
            CKEDITOR.replace( 'editor1' );
        </script>
                        </div>
                        </div>

                        <div class="form-group row col-md-12">
                        <label for="example-text-input" class="col-sm-2 col-form-label">Yorum işlem :  </label>
                        <div class="col-sm-9">
                        <select name="yorum_islem" style="padding: 5px; border-radius: 5px;">
                            <option value="1" <?php echo $yorumcek["yorum_durum"]==1 ? 'selected' : null; ?>>Onaylı</option >
                            <option value="0" <?php echo $yorumcek["yorum_durum"]==0 ? 'selected' : null; ?>>Onaylı değil</option>
                        </select>
                        </div>
                        </div>

                        
                        <div class="form-group row col-md-12">
                        <input type="submit" name="comments" class="btn btn-success" value="Düzenle">
                        </div>
                        </div>
                        



                                    </div>

                                </div>
                        </div>


         <?php include 'footer.php'; ?>