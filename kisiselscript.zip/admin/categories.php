<?php include 'header.php'; 
if(!isset($_SESSION["admin_kadi"])){
    header("Location: login.php");
}
?>
        <!-- Main content -->
                <div class="content">
                    <div class="row">

                            <div class="col-sm-12 col-md-12">
                            <div style="float: right; padding: -5px;"><a href="kategoriekle.php"><button style="float: right; padding: 5px;" class="btn btn-success">Kategori Ekle</button></a></div>
                                 <h3 style="font-weight: bolder;"> KATEGORİLER </h3> 
                                  



<span>

                                        <?php   if (@$_GET['kategoriekle']=="yetersiz") { 

                                                echo "<span style='color: orange;'><em>Fotoğraf boyutu çok büyük!</em></span>";
                                                

                                                }elseif (@$_GET['kategoriekle']=="no") { 

                                                echo "<span style='color: red;'><em>Fotoğraf yüklenirken bir hata oluştu!</em></span>";

                                                }elseif (@$_GET['kategoriekle']=="noo") { 

                                                echo "<span style='color: red;'><em>Fotoğraff yüklenirken bir hata oluştu!</em></span>";

                                                }elseif (@$_GET['kategoriekle']=="yes") { 

                                                echo "<span style='color: green; float: left'><em>Kategori başarıyla eklendi!</em></span>";

                                                }elseif (@$_GET['kategoriekle']=="gecersiz") { 

                                                echo "<span style='color: red;'><em>Dosya PNG veya JPG formatında olmalıdır!!</em></span>";

                                                }
                                   /* ?>
                                            </span>
                                  
                                  <span>

                                        <?php*/   elseif (@$_GET['kategoriduzenle']=="yetersiz") { 

                                                echo "<span style='color: orange;'><em>Fotoğraf boyutu çok büyük!</em></span>";

                                                }elseif (@$_GET['kategoriduzenle']=="no") { 

                                                echo "<span style='color: red;'><em>Fotoğraf yüklenirken bir hata oluştu!</em></span>";

                                                }elseif (@$_GET['kategoriduzenle']=="noo") { 

                                                echo "<span style='color: red;'><em>Fotoğraf yüklenirken bir hata oluştu!</em></span>";

                                                }elseif (@$_GET['kategoriduzenle']=="yes") { 

                                                echo "<span style='color: green;'><em>Kategori başarıyla güncellendi!</em></span>";

                                                }elseif (@$_GET['kategoriduzenle']=="gecersiz") { 

                                                echo "<span style='color: red;'><em>Dosya PNG veya JPG formatında olmalıdır!!</em></span>";

                                                }
                                 /*   ?>
                                            </span>

              <span>

                                        <?php */  elseif (@$_GET['katsil']=="yes") { 

                                                echo "<span style='color: green;'><em>Kategori başarıyla silindi!</em></span>";
                                                

                                                }elseif (@$_GET['katsil']=="no") { 

                                                echo "<span style='color: red;'><em>Kategori silinirken bir hata oluştu!</em></span>";

                                                }
                                                
                                                ?>
                            </span>  
                            <div style="clear: both;"></div>                 
<hr style="height: 2px; background: #ccc;">
                       </div>


  <div class="col-md-12">
  <div class="table-responsive">          
  <table class="table">
    <thead>
      <tr>
        <th style="text-align: center;" width="50">#</th>
        <th style="text-align: center;" width="200">Resim</th>
        <th style="text-align: center;" width="300">Kategori ismi</th>
        <th style="text-align: center;" width="300">Yazı Sayısı</th>
        <th style="text-align: center;">İşlemler</th>
      </tr>
    </thead>
    <tbody>
      <?php

      $kategoriler = $db->prepare("SELECT * FROM kategoriler
        ORDER BY kat_id DESC
        ");
      $kategoriler->execute();
      $kategori = $kategoriler->fetchALL(PDO::FETCH_ASSOC);

      $katsay = $kategoriler->rowCount();

      if ($katsay) {
        
        foreach ($kategori as $katcek) {
            ?>
<tr>
            <td style="text-align: center;"><?php echo $katcek["kat_id"]; ?></td>
        <td style="text-align: center;"><img width="60" height="60" style="border-radius: 50%;" src="../images/kategoriler/<?php echo $katcek["kat_resim"]; ?>"></td>
        <td style="text-align: center;"><?php echo $katcek["kat_isim"]; ?></td>
        <!-- kategorideki yazi sayısı -->
         <?php

                                                                    $query = $db->prepare("SELECT * FROM yazilarim WHERE yazi_kategori=?");
                                                                    $query->execute(array($katcek["kat_id"]));
                                                                    $toplam = $query->rowCount();
                                                                   
                                                        ?>
        <td style="text-align: center;"><?php echo $toplam; ?></td>
        <td style="text-align: center;">
        <a href="kategoriduzenle.php?id=<?php echo $katcek["kat_id"]; ?>"><button  style="background: #1a426c; color: white; padding: 5px; border-radius: 5px; border: 1px solid #1a426c;" ><i class="fa fa-edit"></i>Düzenle</button></a>
        <a href="islem.php?kat_id=<?php echo $katcek["kat_id"]; ?>"><button  style="background: darkred; color: white; padding: 5px; border-radius: 5px; border: 1px solid darkred;" ><i class="fa fa-trash"></i>Sil&nbsp;</button></a>        
        </td>
 </tr>
            <?php
        }

      }


      ?>
        
     
    </tbody>
  </table>
  </div>       
</div>
<hr>
                                  

                               
                            </div>
                        </div>


       <?php include 'footer.php'; ?>