<?php include 'header.php';
if(!isset($_SESSION["admin_kadi"])){
    header("Location: login.php");
}
?>
        <!-- Main content -->
                <div class="content">
                    <div class="row">

                           
        <div class="col-sm-12 col-md-12">
                                 <h3 style="font-weight: bolder; margin-top: 0"> MESAJ OKUNUYOR... </h3> 
                           
                            <div style="clear: both;"></div>                 
<hr style="height: 2px; background: #ccc;">
                       </div>
<div class="col-sm-12 col-md-12">
        <div class="row" >
        <?php 

        $mesaj_id = $_GET["id"];

        $mesaj = $db->prepare("SELECT * FROM mesajlar WHERE mesaj_id=?");
        $mesaj->execute(array($mesaj_id));
        $mesajcek = $mesaj->fetch(PDO::FETCH_ASSOC);
        $mesajsay = $mesaj->rowCount();

        if ($mesajsay) {

        	$mesajlar = $db->prepare("UPDATE mesajlar SET mesaj_okunma=? WHERE mesaj_id=?");
        	$mesajlar->execute(array(1,$mesaj_id));



        	?>

        	 <div class="col-lg-4 col-xs-12 col-md-12 top10">
                <ul class="list-group">
                    <li class="list-group-item" style="border-radius: 0;">
                        <b>Mesajı Gönderen :</b> <?php echo $mesajcek["mesaj_gonderenisim"];?>
                    </li>
                </ul>
            </div>

             <div class="col-lg-4 col-xs-12 col-md-12 top10">
                <ul class="list-group">
                    <li class="list-group-item" style="border-radius: 0;">
                        <b>E-Mail :</b> <?php echo $mesajcek["mesaj_gonderenmail"];?>
                    </li>
                </ul>
            </div>

            <div class="col-lg-4 col-xs-12 col-md-12 top10">
                <ul class="list-group">
                    <li class="list-group-item" style="border-radius: 0;">
                        <b>Tarih :</b> <?php echo timeAgo($mesajcek["mesaj_tarihi"]);?>
                    </li>
                </ul>
            </div>

            <div class="col-lg-12 col-xs-12 col-md-12">
                <ul class="list-group">
                    <li class="list-group-item" style="border-radius: 0;">
                        <b>Mesaj Konusu :</b>
                        <?php echo $mesajcek["mesaj_konu"];?>
                    </li>
                </ul>
            </div>

            <div class="col-lg-12 col-xs-12 col-md-12">
                <ul class="list-group">
                    <li class="list-group-item" style="border-radius: 0;">
                        <b>Mesaj :</b><br>
                        <p><?php echo $mesajcek["mesaj_aciklama"];?></p>
                    </li>
                </ul>
            </div>

            <div class="col-lg-12 col-xs-12 col-md-12">
                <a href="messages.php"><button class="btn btn-info"><span class="fa fa-mail-reply"></span> Mesajlara geri dön!</button></a>
                <a href="islem.php?mesajsil=<?php echo $mesajcek["mesaj_id"]; ?>" style="text-align: right;"><button class="btn btn-danger"><span class="fa fa-trash"></span> Mesaj sil!</button></a>
            </div>


        	<?php
        }


        ?>
           


         
</div>


 
                                </div> 
</div>
<hr>
                                  

                               
                            </div>




       <?php include 'footer.php'; ?>

