<?php include 'header.php'; 
if(!isset($_SESSION["admin_kadi"])){
    header("Location: login.php");
}
?>


 <?php
                                    $id = @$_GET["id"];
                                    $referanslar = $db->prepare("SELECT * FROM referanslar 
                                    WHERE ref_id=?");
                                    $referanslar->execute(array($id));
                                    $refcek = $referanslar->fetch(PDO::FETCH_ASSOC);
?>

 


        <!-- Main content -->
                <div class="content">
                    <div class="row">

                        <div class="col-sm-12 col-md-12">
                                 <h3 style="font-weight: bolder; margin: 0"> REFERANS DÜZENLE </h3>

<hr style="height: 2px; background: #ccc;">
                       </div>

                        <div class="col-sm-12 col-md-12">
                        
                        <form action="islem.php" method="POST" enctype="multipart/form-data">
                        <div class="panel-body">

                                  
                                
                                    <div class="form-group row col-md-12">
                                        <label for="exampleInputFile" class="col-sm-2">Resim Seçin :</label>
                                        <div class="col-sm-9">
                                        
                                        <input class="form-control" type="file" name="ref_resim">
                                        </div>

                                    </div>

                        <div class="form-group row col-md-12">
                        <label for="example-text-input" class="col-sm-2 col-form-label">Referans Başlık :  </label>
                        <div class="col-sm-9">
                        <input class="form-control" name="ref_baslik" type="text" required="" placeholder="Lütfen yazinizin başlığını yazınız...">
                        </div>
                        </div>


                        <div class="form-group row col-md-12">
                        <label for="example-text-input" class="col-sm-2 col-form-label">Referans Link :  </label>
                        <div class="col-sm-9">
                        <input class="form-control" name="ref_link" type="text" value="http://" required="">
                      
                        </div>
                        </div>
                        
                        <div class="form-group row col-md-12">
                        <input type="submit" name="ref_ekle" class="btn btn-success" value="Referans Ekle...">
                        </div>
                        </div>
                        



                                    </div>

                                </div>
                        </div>


         <?php include 'footer.php'; ?>