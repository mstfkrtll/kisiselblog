
 <div class="sidebar" data-color="red" data-image="assets/img/sidebar-1.jpg">

    <!--

        Tip 1: you can change the color of the sidebar using: data-color="blue | azure | green | orange | red | purple"
        Tip 2: you can also add an image using data-image tag

    -->

    	<div class="sidebar-wrapper">
            <div class="logo">
                <a href="http://www.creative-tim.com" class="simple-text">
                   <img width="100px" height="100px" style="border-radius: 50%;" src="../images/<?php echo $hakkimdacek["hakkimda_foto"]; ?>"><br>
                </a>
            </div>

            <ul class="nav">
                <li class="active">
                    <a href="index.php">
                        <i class="pe-7s-home"></i>
                        <p>HOME</p>
                    </a>
                </li>
                <li>
                    <a href="settings.php">
                        <i class="pe-7s-config"></i>
                        <p>SETTINGS</p>
                    </a>
                </li>
                <li>
                    <a href="myabout.php">
                        <i class="pe-7s-info"></i>
                        <p>My About</p>
                    </a>
                </li>

                <li>
                    <a href="mywritings.php">
                        <i class="pe-7s-note2"></i>
                        <p>My writings</p>
                    </a>
                </li>

                <li>
                    <a href="references.php">
                        <i class="pe-7s-portfolio"></i>
                        <p>references</p>
                    </a>
                </li>
                <li>
                    <a href="categories.php">
                        <i class="pe-7s-pin"></i>
                        <p>categories</p>
                    </a>
                </li>
                <li>
                    <a href="myprojects.php">
                        <i class="pe-7s-coffee"></i>
                        <p>My Projects</p>
                    </a>
                </li>
                <li>
                    <a href="comments.php">
                        <i class="pe-7s-comment"></i>
                        <p>COMMENTS</p>
                    </a>
                </li>
                <li>
                    <a href="messages.php">

                        <i class="pe-7s-mail"></i>
                        <?php 
                        $mesajlar = $db->prepare("SELECT * FROM mesajlar WHERE mesaj_okunma=?");
                        $mesajlar->execute(array(0));
                        $mesajsay = $mesajlar->rowCount();
                           ?>
                           <p>MESSAGES <span class="label text-danger" style="background: #fff; font-size: 10px; text-align: right;"><?php echo $mesajsay; ?></span></p>
                        
                    </a>
                </li>
            </ul>
    	</div>
    </div>