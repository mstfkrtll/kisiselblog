<?php include 'header.php'; 
if(!isset($_SESSION["admin_kadi"])){
    header("Location: login.php");
}
?>
 <?php
                                    $id = @$_GET["id"];
                                    $kategoriler = $db->prepare("SELECT * FROM kategoriler WHERE kat_id=?");
                                    $kategoriler->execute(array($id));
                                    $katcek = $kategoriler->fetch(PDO::FETCH_ASSOC);
?>



        <!-- Main content -->
                <div class="content">
                    <div class="row">

                        <div class="col-sm-12 col-md-12">
                                 <h3 style="font-weight: bolder;"> YAZI DÜZENLE </h3>

<hr style="height: 2px; background: #ccc;">
                       </div>

                        <div class="col-sm-12 col-md-12">
                        
                        <form action="islem.php?id=<?php echo $id; ?>" method="POST" enctype="multipart/form-data">
                        <div class="panel-body">

                        <div class="form-group row col-md-12">
                                        <label for="exampleInputFile" class="col-sm-2">Resim Seçin :</label>
                                        <div class="col-sm-9">
                                        <img width="150" height="150"  src="../images/kategoriler/<?php echo $katcek["kat_resim"]; ?>" alt="">
                                        </div>

                                    </div>
                                  
                                
                                    <div class="form-group row col-md-12">
                                        <label for="exampleInputFile" class="col-sm-2">Resim Seçin :</label>
                                        <div class="col-sm-9">
                                        
                                        <input class="form-control" type="file" name="kat_resim">
                                        </div>

                                    </div>

                        <div class="form-group row col-md-12">
                        <label for="example-text-input" class="col-sm-2 col-form-label">Kategori Başlık :  </label>
                        <div class="col-sm-9">
                        <input class="form-control" name="kat_baslik" value="<?php echo $katcek["kat_isim"]; ?>" type="text" required="" placeholder="Lütfen kişi adını giriniz.">
                        </div>
                        </div>

                        
                        <div class="form-group row col-md-12">
                        <input type="submit" name="categories" class="btn btn-success" value="Düzenle">
                        </div>
                        </div>
                        



                                    </div>

                                </div>
                        </div>


         <?php include 'footer.php'; ?>