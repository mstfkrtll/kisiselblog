<?php include 'header.php'; 
if(!isset($_SESSION["admin_kadi"])){
    header("Location: login.php");
}
?>
        <!-- Main content -->
                <div class="content">
                    <div class="row">

                            <div class="col-sm-12 col-md-12">
                            <div style="float: right; padding: -5px;"><a href="referansekle.php"><button style="float: right; padding: 5px;" class="btn btn-success">Referans Ekle</button></a></div>
                                 <h3 style="font-weight: bolder; margin-top: 0"> REFERANSLAR </h3> 
                                  

                                 <span>

                                        <?php   if (@$_GET['referansekle']=="yetersiz") { 

                                                echo "<span style='color: orange;'><em>Fotoğraf boyutu çok büyük!</em></span>";
                                                

                                                }elseif (@$_GET['referansekle']=="no") { 

                                                echo "<span style='color: red;'><em>Fotoğraf yüklenirken bir hata oluştu!</em></span>";

                                                }elseif (@$_GET['referansekle']=="noo") { 

                                                echo "<span style='color: red;'><em>Fotoğraf yüklenirken bir hata oluştu!</em></span>";

                                                }elseif (@$_GET['referansekle']=="yes") { 

                                                echo "<span style='color: green; float: left'><em>Referans başarıyla eklendi!</em></span>";

                                                }elseif (@$_GET['referansekle']=="gecersiz") { 

                                                echo "<span style='color: red;'><em>Dosya PNG veya JPG formatında olmalıdır!!</em></span>";

                                                }
                                  /*  ?>
                                            </span>


        <span>

                                        <?php*/   elseif (@$_GET['referansduzenle']=="yetersiz") { 

                                                echo "<span style='color: orange;'><em>Fotoğraf boyutu çok büyük!</em></span>";
                                                

                                                }elseif (@$_GET['referansduzenle']=="no") { 

                                                echo "<span style='color: red;'><em>Fotoğraf yüklenirken bir hata oluştu!</em></span>";

                                                }elseif (@$_GET['referansduzenle']=="noo") { 

                                                echo "<span style='color: red;'><em>Fotoğraf yüklenirken bir hata oluştu!</em></span>";

                                                }elseif (@$_GET['referansduzenle']=="yes") { 

                                                echo "<span style='color: green; float: left'><em>Referans başarıyla güncellendi!</em></span>";

                                                }elseif (@$_GET['referansduzenle']=="gecersiz") { 

                                                echo "<span style='color: red;'><em>Dosya PNG veya JPG formatında olmalıdır!!</em></span>";

                                                }
                                   /* ?>
                                            </span>
        <span>

                                        <?php  */ elseif (@$_GET['refsil']=="yes") { 

                                                echo "<span style='color: green;'><em>Referans başarıyla silindi!</em></span>";
                                                

                                                }elseif (@$_GET['refsil']=="no") { 

                                                echo "<span style='color: red;'><em>Referans silinirken bir hata oluştu!</em></span>";

                                                }
                                                
                                                ?>
                            </span> 
 <div style="clear: both;"></div>
                            
<hr style="height: 2px; background: #ccc;">
                       </div>

                                            


  <div class="col-md-12">
  <div class="table-responsive">          
  <table class="table">
    <thead>
      <tr>
        <th width="50">#</th>
        <th width="200">Resim</th>
        <th width="200">Başlık</th>
        <th width="400">Link</th>
        <th>İşlemler</th>
      </tr>
    </thead>
    <tbody>
      <?php

      $referanslar = $db->prepare("SELECT * FROM referanslar
        ORDER BY ref_id DESC
        ");
      $referanslar->execute();
      $referans = $referanslar->fetchALL(PDO::FETCH_ASSOC);

      $refsay = $referanslar->rowCount();

      if ($refsay) {
        
        foreach ($referans as $refcek) {
            ?>
<tr>
            <td><?php echo $refcek["ref_id"]; ?></td>
        <td><img width="100" height="50" src="../images/referanslar/<?php echo $refcek["ref_resim"]; ?>"></td>
        <td><?php echo $refcek["ref_baslik"]; ?></td>
        <td><?php echo $refcek["ref_link"]; ?></td>
        <td>
        <a href="referansduzenle.php?id=<?php echo $refcek["ref_id"]; ?>"><button  style="background: #1a426c; color: white; padding: 5px; border-radius: 5px; border: 1px solid #1a426c;" ><i class="fa fa-edit"></i>Düzenle</button></a>
        <a href="islem.php?ref_id=<?php echo $refcek["ref_id"]; ?>"><button  style="background: darkred; color: white; padding: 5px; border-radius: 5px; border: 1px solid darkred;" ><i class="fa fa-trash"></i>Sil&nbsp;</button></a>        
        </td>
 </tr>
            <?php
        }

      }


      ?>
        
     
    </tbody>
  </table>
  </div>       
</div>
<hr>
                                    

                                
                               
                            </div>
                        </div>


            <?php include 'footer.php'; ?>
