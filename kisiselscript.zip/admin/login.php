<?php include '../sistem/ayar.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>

     <meta charset="UTF-8">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <meta http-equiv="X-UA-Compatible" content="ie=edge">
     <title><?php echo $ayarrow["site_title"]; ?></title>

     <!-- SWEET ALERT -->
    <script type="text/javascript" src="http://code.jquery.com/jquery-latest.min.js"></script>
    <script src="assets/js/sweetalert.min.js"></script>


    <link rel="stylesheet" type="text/css" href="assets/css/sweetalert.css">
    <!-- SWEET ALERT SONU -->

     <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:100,300,400,500,700,900">
     <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
     <link rel="stylesheet" href="../assets/plugins/bootstrap/css/bootstrap.min.css">
     <link rel="stylesheet" href="../assets/plugins/bootstrap/css/bootstrap-flex.min.css">
     <link rel="stylesheet" href="../assets/plugins/tether/css/tether.min.css">
     <link rel="stylesheet" href="../assets/plugins/jQueryFiler/css/jquery.filer.css">
     <link rel="stylesheet" href="../assets/plugins/toastr8/toastr8.min.css">
     <link rel="stylesheet" href="../assets/css/style.css">

     <style type="text/css">
     	@media only screen and (max-width: 960px) {
     		img{margin-left: 30px;}
     		input{margin-left: 65px; margin-top: 10px;}
     		button{margin-left: 120px; margin-top: 10px;}
     	}
     </style>

     <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
     <script type="text/javascript" src="../assets/plugins/tether/js/tether.min.js"></script>
     <script type="text/javascript" src="../assets/plugins/bootstrap/js/bootstrap.min.js"></script>
     <script type="text/javascript" src="../assets/plugins/jQueryFiler/js/jquery.filer.min.js"></script>
     <script type="text/javascript" src="../assets/plugins/toastr8/toastr8.min.js"></script>
     <script type="text/javascript" src="../assets/js/app.js"></script>

</head>
<body id="login">

<form action="islem.php" method="POST">
   <!--   <div class="form"> -->
          <img src="../<?php echo $ayarrow["site_logo"]; ?>" style="border-radius: 50%; width: 250px;" alt="">
       
               <input style="border-radius: 5px; padding: 5px;" type="text" name="admin_kadi" placeholder="Kullanıcı adı">
        

        
               <input style="border-radius: 5px; padding: 5px;" type="password" name="admin_sifre" placeholder="Şifreniz">
         

               <button style="border-radius: 5px; padding: 5px;" type="submit" class="btn btn-success" name="loggin">Giriş Yap</button>
          <?php

                                    if(@$_GET["login"]=="no"){
                                        echo "<span class='text-danger' style='padding: 5px; background: #fff; border-radius: 5px;'>Kullanıcı adı veya Şifreniz yanlış..!</span>";
                                    }

                                ?>
     <!-- </div> -->
</form>


</body>
</html>
