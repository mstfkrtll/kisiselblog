<?php include 'header.php'; 
if(!isset($_SESSION["admin_kadi"])){
    header("Location: login.php");
}
?>
        <!-- Main content -->
                <div class="content">
                    <div class="row">

                            <div class="col-sm-12 col-md-12">
                                 <h3 style="font-weight: bolder; margin-top: 0"> YORUMLAR </h3> 
                                  
<span>

                                        <?php   if (@$_GET['duzenle']=="yes") { 

                                                echo "<span style='color: green;'><em>Yorum başarıyla düzenlendi!</em></span>";

                                                }elseif (@$_GET['duzenle']=="no") { 

                                                echo "<span style='color: red;'><em>Yorum güncellenirken bir hata oluştu!</em></span>";

                                                }
                                 /*   ?>
                                            </span>

              <span>

                                        <?php */  elseif (@$_GET['commentsil']=="yes") { 

                                                echo "<span style='color: green;'><em>Yorum başarıyla silindi!</em></span>";
                                                

                                                }elseif (@$_GET['commentsil']=="no") { 

                                                echo "<span style='color: red;'><em>Yorum silinirken bir hata oluştu!</em></span>";

                                                }
                                                
                                                ?>
                            </span>  
                            <div style="clear: both;"></div>                 
<hr style="height: 2px; background: #ccc;">
                       </div>



  <div class="col-md-12">
  <div class="table-responsive">          
  <table class="table">
    <thead>
      <tr >
        <th style="text-align: center;" width="30">#</th>
        <th style="text-align: center;" width="80">Resim</th>
        <th style="text-align: center;" width="120">Yorum Ekleyen</th>
        <th style="text-align: center;" width="550">Yorum İçerik</th>
        <th style="text-align: center;" width="80">Onay</th>
        <th style="text-align: center;">İşlemler</th>
      </tr>
    </thead>
    <tbody>
      <?php 

                              $yorumlar = $db->prepare("SELECT * FROM yorumlar 
                                   INNER JOIN yazilarim ON yazilarim.yazi_id = yorumlar.yorum_konu_id
                                   ORDER BY yorum_id DESC");
                              $yorumlar->execute();
                              $yorum = $yorumlar->fetchALL(PDO::FETCH_ASSOC);
                              $yorumsay = $yorumlar->rowCount();

                              if($yorumsay){

                              foreach($yorum as $yorumcek) {
                              ?>
<tr>
            <td><b><?php echo $yorumcek["yorum_id"]; ?></b></td>
        <td><a href="../icerik.php?id=<?php echo $yorumcek["yazi_id"]; ?>" target="_blank"><img width="60" height="60" style="border-radius: 50%;" src="../images/yazilarim/<?php echo $yorumcek["yazi_resim"]; ?>"></a></td>
        <td style="text-align: center;"><b><?php echo $yorumcek["yorum_ekleyen"]; ?></b></td>
        
        <td><em><?php echo $yorumcek["yorum_icerik"]; ?></em></td>
        <td style="text-align: center;">
                            <?php
                              if ($yorumcek["yorum_durum"]==1) {
                                
                                echo '<span style="color: green;" class="fa fa-check"></span>';
                              }else{

                                echo '<span style="color: darkred;" class="fa fa-remove"></span>';
                              }

                            ?>
                            </td>
        <td style="text-align: center;">
        <a href="yorumduzenle.php?id=<?php echo $yorumcek["yorum_id"]; ?>"><button  style="background: #1a426c; color: white; padding: 5px; border-radius: 5px; border: 1px solid #1a426c;" ><i class="fa fa-edit"></i>Düzenle</button></a>
        <a href="islem.php?yorum_id=<?php echo $yorumcek["yorum_id"]; ?>"><button  style="background: darkred; color: white; padding: 5px; border-radius: 5px; border: 1px solid darkred;" ><i class="fa fa-trash"></i>Sil&nbsp;</button></a>        
        </td>
 </tr>
            <?php
        }

      }


      ?>
        
     
    </tbody>
  </table>
  </div>       
</div>
<hr>
                                  

                               
                            </div>
                        </div>


       <?php include 'footer.php'; ?>

