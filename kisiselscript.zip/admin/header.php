<?php include '../sistem/ayar.php';
      include '../sistem/tarih_fonksiyon.php';
 ?>

<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<link rel="icon" type="image/png" href="assets/img/<?php echo $ayarrow["site_favicon"]; ?>">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

	<title><?php echo $ayarrow["site_title"]; ?> Yönetim Paneli</title>

	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />
    <!-- SWEET ALERT -->
    <script type="text/javascript" src="http://code.jquery.com/jquery-latest.min.js"></script>
    <script src="assets/js/sweetalert.min.js"></script>


    <link rel="stylesheet" type="text/css" href="assets/css/sweetalert.css">
    <!-- SWEET ALERT SONU -->

 <!-- CK EDİTÖR -->
    <script src="//cdn.ckeditor.com/4.7.0/basic/ckeditor.js"></script>
    <!-- <script src="assets/js/ckeditor.js"></script> -->

    <!-- Bootstrap core CSS     -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" />

    <!-- Animation library for notifications   -->
    <link href="assets/css/animate.min.css" rel="stylesheet"/>

    <!--  Light Bootstrap Table core CSS    -->
    <link href="assets/css/light-bootstrap-dashboard.css" rel="stylesheet"/>


    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="assets/css/demo.css" rel="stylesheet" />


    <!--     Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Roboto:400,700,300' rel='stylesheet' type='text/css'>
    <link href="assets/css/pe-icon-7-stroke.css" rel="stylesheet" />

</head>
<body>

<div class="wrapper">
<!-- SİDEBAR -->
   <?php include 'sidebar.php'; ?>
 


    <div class="main-panel">
        <?php include 'ustmenu.php'; ?>
