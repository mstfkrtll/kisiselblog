<?php include 'header.php'; 
if(!isset($_SESSION["admin_kadi"])){
    header("Location: login.php");
}
?>
        <!-- Main content -->
                <div class="content">
                    <div class="row">

                            <div class="col-sm-12 col-md-12">
                            <div style="float: right; padding: -5px;"><a href="yaziekle.php"><button style="float: right; padding: 5px;" class="btn btn-success">Yazı Ekle</button></a></div>
                            
                                 <h3 style="font-weight: bolder; margin-top:0;"> YAZILARIM </h3> 
                                  
                                  <!-- BİLGİLENDİRME -->

                                  <span>

                                        <?php   if (@$_GET['yaziekle']=="yetersiz") { 

                                                echo "<span style='color: orange;'><em>Fotoğraf boyutu çok büyük!</em></span>";
                                                

                                                }elseif (@$_GET['yaziekle']=="no") { 

                                                echo "<span style='color: red;'><em>Fotoğraf yüklenirken bir hata oluştu!</em></span>";

                                                }elseif (@$_GET['yaziekle']=="noo") { 

                                                echo "<span style='color: red;'><em>Fotoğraff yüklenirken bir hata oluştu!</em></span>";

                                                }elseif (@$_GET['yaziekle']=="yes") { 

                                                echo "<span style='color: green; float: left'><em>Yazı başarıyla eklendi!</em></span>";

                                                }elseif (@$_GET['yaziekle']=="gecersiz") { 

                                                echo "<span style='color: red;'><em>Dosya PNG veya JPG formatında olmalıdır!!</em></span>";

                                                }
/*                                    ?>
                                            </span>
                                  
                                  <span>

                                        <?php*/   elseif (@$_GET['yaziduzenle']=="yetersiz") { 

                                                echo "<span style='color: orange;'><em>Fotoğraf boyutu çok büyük!</em></span>";

                                                }elseif (@$_GET['yaziduzenle']=="no") { 

                                                echo "<span style='color: red;'><em>Fotoğraf yüklenirken bir hata oluştu!</em></span>";

                                                }elseif (@$_GET['yaziduzenle']=="noo") { 

                                                echo "<span style='color: red;'><em>Fotoğraf yüklenirken bir hata oluştu!</em></span>";

                                                }elseif (@$_GET['yaziduzenle']=="yes") { 

                                                echo "<span style='color: green;'><em>Yazı başarıyla güncellendi!</em></span>";

                                                }elseif (@$_GET['yaziduzenle']=="gecersiz") { 

                                                echo "<span style='color: red;'><em>Dosya PNG veya JPG formatında olmalıdır!!</em></span>";

                                                }
                                   /* ?>
                                            </span>

              <span>

                                        <?php*/  elseif (@$_GET['yazisil']=="yes") { 

                                                echo "<span style='color: green;'><em>Yazı başarıyla silindi!</em></span>";
                                                

                                                }elseif (@$_GET['yazisil']=="no") { 

                                                echo "<span style='color: red;'><em>Yazı silinirken bir hata oluştu!</em></span>";

                                                }
                                                
                                                ?>
                            </span>   
                                  <div style="clear: both;"></div>
<hr style="height: 2px; background: #ccc;">
                       </div>
  


  <div class="col-md-12">
  <div class="table-responsive">          
  <table class="table">
    <thead>
      <tr>
        <th style="text-align: center;" width="50">#</th>
        <th style="text-align: center;" width="100">Resim</th>
        <th style="text-align: center;" width="450">Başlık</th>
        <th style="text-align: center;" width="250">Kategori</th>
        <th style="text-align: center;">İşlemler</th>
      </tr>
    </thead>
    <tbody>
      <?php

      $yazilarim = $db->prepare("SELECT * FROM yazilarim
        INNER JOIN kategoriler ON kategoriler.kat_id = yazilarim.yazi_kategori
        ORDER BY yazi_id DESC
        ");
      $yazilarim->execute();
      $yazi = $yazilarim->fetchALL(PDO::FETCH_ASSOC);

      $yazisay = $yazilarim->rowCount();

      if ($yazisay) {
        
        foreach ($yazi as $yazicek) {
            ?>
<tr>
            <td style="text-align: center;"><?php echo $yazicek["yazi_id"]; ?></td>
        <td style="text-align: center;"><img width="100" height="75px" src="../images/yazilarim/<?php echo $yazicek["yazi_resim"]; ?>"></td>
        <td style="text-align: center;"><?php echo $yazicek["yazi_baslik"]; ?></td>
        <td style="text-align: center;"><?php echo $yazicek["kat_isim"]; ?></td>
        <td style="text-align: center;">
        <a href="yaziduzenle.php?id=<?php echo $yazicek["yazi_id"]; ?>"><button  style="background: #1a426c; color: white; padding: 5px; border-radius: 5px; border: 1px solid #1a426c;" ><i class="fa fa-edit"></i>Düzenle</button></a>
        <a href="islem.php?yazi_id=<?php echo $yazicek["yazi_id"]; ?>"  onclick="silOnayla();"><button  style="background: darkred; color: white; padding: 5px; border-radius: 5px; border: 1px solid darkred;" ><i class="fa fa-trash"></i>Sil&nbsp;</button></a>

        </td>
 </tr>
            <?php
        }

      }


      ?>
        
     
    </tbody>
  </table>
  </div>       
</div>

                                    
                                
                              

                                
                               
                            </div>
                        </div>


          <?php include 'footer.php'; ?>