
     
          <div class="container-fluid" style="color: white; text-shadow: 4px 4px 4px #444;">2017 &copy; Mstfkrtll.com | Her hakkı saklıdır...</div>
    


              <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
     <script type="text/javascript" src="<?php echo $ayarrow["site_url"]; ?>assets/plugins/tether/js/tether.min.js"></script>
     <script type="text/javascript" src="<?php echo $ayarrow["site_url"]; ?>assets/plugins/bootstrap/js/bootstrap.min.js"></script>
     <script type="text/javascript" src="<?php echo $ayarrow["site_url"]; ?>assets/plugins/jQueryFiler/js/jquery.filer.min.js"></script>
     <script type="text/javascript" src="<?php echo $ayarrow["site_url"]; ?>assets/plugins/toastr8/toastr8.min.js"></script>
     <script type="text/javascript" src="<?php echo $ayarrow["site_url"]; ?>assets/js/app.js"></script>



</body>
</html>
