<?php include 'header.php'; ?>



     <div id="content" class="mt-2">
          <div class="container">
               <div class="row">
                    <div class="card card-info widget" id="search-widget" style="background: #FF8F00; width: 100%;" >
                              <div class="card-header">
                                   <i class="material-icons">local_offer</i>
                                   Kategoriler
                              </div>
               <div class="col-md-12" style="background: #f9f9f1; padding-top: 20px;">

                    <?php 

                    $kategoriler = $db->prepare("SELECT * FROM kategoriler");
                    $kategoriler->execute();
                    $kategori = $kategoriler->fetchALL(PDO::FETCH_ASSOC);
                    $katsor = $kategoriler->rowCount();

                    if ($katsor) {
                        
                         foreach ($kategori as $katcek) {
                             ?>

                               <div class="col-lg-3">
                                   <a href="<?php echo $ayarrow["site_url"]; ?>tag_list/<?php echo seo($katcek["kat_isim"]).'/'.$katcek["kat_id"]; ?>" style="text-decoration: none;"><div class="card tag-widget" style="color: #FF8F00;">
                                        <div class="card-img">
                                             <img src="images/kategoriler/<?php echo $katcek["kat_resim"]; ?>" alt="">
                                        </div>
                                        <div class="card-block">
                                             <div class="card-title"><?php echo $katcek["kat_isim"]; ?></div>
                                        </div>
                                   </div></a>
                              </div>

                             <?php
                         }

                    }else{
                         echo "<h6>Kategori bulunmamaktadır!</h6>";
                    }

                    ?>

                   

               </div>

          </div>
          </div>
     </div>

     <!-- Add Tag -->
     <div class="modal fade in" id="add_tag" tabindex="-1">
          <div class="modal-dialog">
               <div class="modal-content">
                    <div class="modal-header">
                         <h4 class="modal-title">Etiket Ekle</h4>
                    </div>
                    <div class="modal-body">
                         <div class="form-group">
                              <label for="">Başlık</label>
                              <input type="text" class="form-control" onkeyup="$('.preview .card-title').text($(this).val());">
                         </div>
                         <div class="form-group">
                              <input type="file" name="logo" id="logo" data-jfiler-limit="1">
                         </div>
                    </div>
                    <div class="modal-footer">
                         <button type="button" class="btn btn-primary fab"><i class="material-icons">send</i></button>
                         <button type="button" class="btn btn-secondary fab" class="close" data-dismiss="modal"><i class="material-icons">close</i></button>
                    </div>
               </div>
          </div>
     </div>

     <!-- Remove Tag -->
     <div class="modal fade" id="remove_tag" tabindex="-1">
          <div class="modal-dialog">
               <div class="modal-content">
                    <div class="modal-header">
                         <h4 class="modal-title">Uyarı</h4>
                    </div>
                    <div class="modal-body">
                         Bu etiketi silmek istediğinize emin misiniz?
                    </div>
                    <div class="modal-footer">
                         <button type="button" class="btn btn-danger fab"><i class="material-icons">delete</i></button>
                         <button type="button" class="btn btn-secondary fab" class="close" data-dismiss="modal"><i class="material-icons">close</i></button>
                    </div>
               </div>
          </div>
     </div>


  <h6 style="text-align: center;"> <?php include 'footer.php'; ?></h6> 
